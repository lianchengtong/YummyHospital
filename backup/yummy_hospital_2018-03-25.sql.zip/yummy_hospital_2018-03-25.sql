# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.7.21)
# Database: yummy_hospital
# Generation Time: 2018-03-25 14:42:25 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table address
# ------------------------------------------------------------

DROP TABLE IF EXISTS `address`;

CREATE TABLE `address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `default` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;

INSERT INTO `address` (`id`, `user_id`, `name`, `phone`, `location`, `default`)
VALUES
	(8,1,'asdf','asdf','asfdasdfasdf',1);

/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table article
# ------------------------------------------------------------

DROP TABLE IF EXISTS `article`;

CREATE TABLE `article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` varchar(255) NOT NULL,
  `head_image` varchar(255) NOT NULL DEFAULT '',
  `category` int(11) NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `author_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;

INSERT INTO `article` (`id`, `title`, `slug`, `head_image`, `category`, `description`, `keyword`, `author_id`, `created_at`, `updated_at`, `type`)
VALUES
	(8,'HelloWOrl','carsol-1','/upload/2017/12/27/9a3e2afa25209f77a1c2b0239bebce72.jpeg',1,'','',1,1514386364,1514386364,2),
	(9,'asdfasdf','i61kT9KlOl3K859e_lCLBuEunuioW3E8','/upload/2017/12/27/9a3e2afa25209f77a1c2b0239bebce72.jpeg',1,'','',1,1514386704,1514386704,2),
	(10,'asfasdf','oDOI-kSZHdARY2O8jRazcPRswaJaKKFc','/upload/2017/12/27/815497711805590cac334176fad9428d.jpg',1,'','',1,1514386736,1514386736,2);

/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table article_content
# ------------------------------------------------------------

DROP TABLE IF EXISTS `article_content`;

CREATE TABLE `article_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) NOT NULL,
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table article_mount_data
# ------------------------------------------------------------

DROP TABLE IF EXISTS `article_mount_data`;

CREATE TABLE `article_mount_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) NOT NULL,
  `tag` varchar(255) NOT NULL,
  `data` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `article_mount_data` WRITE;
/*!40000 ALTER TABLE `article_mount_data` DISABLE KEYS */;

INSERT INTO `article_mount_data` (`id`, `article_id`, `tag`, `data`)
VALUES
	(1,8,'link','http://baidu.com'),
	(2,9,'link','http://baidu.com'),
	(3,10,'link','http://baidu.com');

/*!40000 ALTER TABLE `article_mount_data` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table article_type
# ------------------------------------------------------------

DROP TABLE IF EXISTS `article_type`;

CREATE TABLE `article_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `slug` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `description` (`description`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `article_type` WRITE;
/*!40000 ALTER TABLE `article_type` DISABLE KEYS */;

INSERT INTO `article_type` (`id`, `name`, `slug`, `description`, `order`)
VALUES
	(1,'通用文章','article','图文并貌的文章类型',123),
	(2,'图片轮播','carsol','图片轮播展示',1);

/*!40000 ALTER TABLE `article_type` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table article_type_field
# ------------------------------------------------------------

DROP TABLE IF EXISTS `article_type_field`;

CREATE TABLE `article_type_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `class` varchar(255) NOT NULL,
  `configure` varchar(255) NOT NULL DEFAULT '',
  `order` int(11) NOT NULL DEFAULT '0',
  `side_show` tinyint(1) NOT NULL DEFAULT '0',
  `field` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `article_type_field` WRITE;
/*!40000 ALTER TABLE `article_type_field` DISABLE KEYS */;

INSERT INTO `article_type_field` (`id`, `type_id`, `name`, `description`, `class`, `configure`, `order`, `side_show`, `field`)
VALUES
	(1,2,'URL链接地址','123123','\\application\\builder\\Input','{\r\n    \"options\": {\r\n        \"class\":\"form-control\"\r\n    }\r\n}',0,0,'link'),
	(2,1,'文章内容','文章内容','\\application\\builder\\Input','{\r\n    \"type\": \"textarea\",\r\n    \"customOptions\": {\r\n        \"rich\": true,\r\n        \"dataProvider\":[\"A\",\"b\",\"c\"]\r\n    }\r\n}',0,0,'content');

/*!40000 ALTER TABLE `article_type_field` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table auth_wechat
# ------------------------------------------------------------

DROP TABLE IF EXISTS `auth_wechat`;

CREATE TABLE `auth_wechat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `open_id` varchar(255) NOT NULL,
  `access_token` varchar(255) NOT NULL,
  `refresh_token` varchar(255) NOT NULL,
  `refresh_token_expire_at` int(11) NOT NULL,
  `access_token_expire_at` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `auth_wechat` WRITE;
/*!40000 ALTER TABLE `auth_wechat` DISABLE KEYS */;

INSERT INTO `auth_wechat` (`id`, `user_id`, `open_id`, `access_token`, `refresh_token`, `refresh_token_expire_at`, `access_token_expire_at`, `created_at`)
VALUES
	(1,3,'oxrAn08P7FtjKly1n3XinIg1BFMQ','5_LqL7H1PFpZlUyWzWxd7j-k_fWIv3Mld9scbJ7SKXrPO0jeQpOvOPnEtYp2qp2JbJ9pXvAjgsB6Q6-55RlYqfFBSZ1k0aac9-BA3OjTlfc_Q','5_u77mbeDAo6cIb9IoVAnQFpC4lpqLUxKdWTJWYGkR6Q084WDeCuMsmo3vIn_tTDi7qE3YvxqNTYik7GtceKiBNQ4gGOSi6d0X5YNF4pNL0ek',1517668330,1515162730,1515162730);

/*!40000 ALTER TABLE `auth_wechat` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table card_password
# ------------------------------------------------------------

DROP TABLE IF EXISTS `card_password`;

CREATE TABLE `card_password` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table category
# ------------------------------------------------------------

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `alias` varchar(120) NOT NULL DEFAULT '',
  `path` varchar(1200) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;

INSERT INTO `category` (`id`, `name`, `alias`, `path`, `pid`, `order`)
VALUES
	(1,'aaaa','aaaa','1',0,0);

/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table code_block
# ------------------------------------------------------------

DROP TABLE IF EXISTS `code_block`;

CREATE TABLE `code_block` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `slug` varchar(255) NOT NULL,
  `code` text NOT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `code_block` WRITE;
/*!40000 ALTER TABLE `code_block` DISABLE KEYS */;

INSERT INTO `code_block` (`id`, `name`, `slug`, `code`, `order`)
VALUES
	(1,'首页九宫格','index.9-grids','<?php\r\nuse yii\\helpers\\Html;\r\nuse yii\\helpers\\Url;\r\n\r\n$gridItems = \\common\\utils\\Cache::getOrSet(\"data.index.9-grids\", function(){\r\n    $indentList = \\common\\models\\LinkGroup::getLinkItems(\"index.9-grid\");\r\n    \r\n    $items = [];\r\n    foreach($indentList as $item){\r\n        $items[]=[\r\n            \"label\" =>$item->name,\r\n            \'url\'   =>$item->getUrl(),\r\n            \'image\'=>$item->getOption(\"image\"),\r\n        ];\r\n    }\r\n    \r\n    return $items;\r\n});\r\n\r\n?>\r\n\r\n<div class=\"row ui-9-grids-wrapper\">\r\n    <div class=\"ui-9-grids\">\r\n        <?php foreach ($gridItems as $item): ?>\r\n            <a href=\"<?= Url::to($item[\'url\']) ?>\" class=\"ui-item\">\r\n                <div class=\"ui-grid-icon\">\r\n                    <?= Html::img($item[\'image\']) ?>\r\n                </div>\r\n                <p class=\"ui-grid-label\"><?= $item[\'label\'] ?></p>\r\n            </a>\r\n        <?php endforeach; ?>\r\n        \r\n    </div>\r\n</div>\r\n\r\n\r\n<!--\r\n<div class=\"row ui-9-grids\">\r\n    <?php foreach ($gridGroupItems as $gridItems): ?>\r\n        <div class=\"ui-3-grid\">\r\n            <?php foreach ($gridItems as $item): ?>\r\n                <a href=\"<?= Url::to($item[\'url\']) ?>\" class=\"ui-col\">\r\n                    <div class=\"ui-grid-icon\">\r\n                        <?= Html::img($item[\'image\']) ?>\r\n                    </div>\r\n                    <p class=\"ui-grid-label\"><?= $item[\'label\'] ?></p>\r\n                </a>\r\n            <?php endforeach; ?>\r\n        </div>\r\n    <?php endforeach; ?>\r\n</div>\r\n\r\n-->\r\n\r\n',0),
	(2,'首页搜索框','index.search-box','<div class=\"ui-searchbar-wrap ui-border-b\">\r\n    <div class=\"ui-searchbar ui-border-radius\">\r\n        <i class=\"ui-icon-search\"></i>\r\n        <div class=\"ui-searchbar-text\">请输入病情</div>\r\n        <div class=\"ui-searchbar-input\">\r\n            <input value=\"\" type=\"tel\" placeholder=\"请输入病情\" autocapitalize=\"off\">\r\n        </div>\r\n        <i class=\"ui-icon-close\"></i>\r\n    </div>\r\n    <button class=\"ui-searchbar-cancel\">取消</button>\r\n</div>\r\n<script>\r\n    $(function () {\r\n        $(\'.ui-searchbar\').click(function () {\r\n            $(\'.ui-searchbar-wrap\').addClass(\'focus\');\r\n            $(\'.ui-searchbar-input input\').focus();\r\n        });\r\n        $(\'.ui-searchbar-cancel\').click(function () {\r\n            $(\'.ui-searchbar-wrap\').removeClass(\'focus\');\r\n        });\r\n        $(\'.ui-icon-close\').click(function () {\r\n            $(\'.ui-searchbar-input input\').val(\"\");\r\n        });\r\n    })\r\n</script>\r\n',0),
	(3,'首页轮播图','index.carousel','<div class=\"row\">\r\n    <?= \\rogeecn\\UnSlider\\Slider::widget([\r\n        \'slides\' => \\common\\utils\\Cache::getOrSet(\"index.carousel\", function () {\r\n            $bannerList = \\common\\models\\LinkGroup::getLinkItems(\"index.carousel\");\r\n            \r\n            $retData     = [];\r\n            /** @var \\common\\models\\LinkGroupItem $article */\r\n            foreach ($bannerList as $linkGroupItem) {\r\n                $retData[] = [\r\n                    \'image\' => $linkGroupItem->getOption(\"image\"),\r\n                    \'url\'   => $linkGroupItem->getUrl(),\r\n                ];\r\n            }\r\n    \r\n            return $retData;\r\n        }),\r\n    ]) ?>\r\n</div>\r\n',0),
	(4,'测试页面数据','page.test','<?php\r\n\r\nuse yii\\helpers\\Html;\r\n\r\n$items = [\r\n    [\r\n        \'label\' => \'首页\',\r\n        \'url\'   => [\'/\'],\r\n    ],\r\n    [\r\n        \'label\' => \'在线问诊\',\r\n        \'url\'   => [\'/ask\'],\r\n    ],\r\n    [\r\n        \'label\' => \'在线预约\',\r\n        \'url\'   => [\'/appointment\'],\r\n    ],\r\n    [\r\n        \'label\' => \'医生详情\',\r\n        \'url\'   => [\'/doctor\'],\r\n    ],\r\n    [\r\n        \'label\' => \'就诊人\',\r\n        \'url\'   => [\'/patient\'],\r\n    ],\r\n    [\r\n        \'label\' => \'确认订单\',\r\n        \'url\'   => [\'/order\'],\r\n    ],\r\n    [\r\n        \'label\' => \'添加、编辑就诊人\',\r\n        \'url\'   => [\'/patient-form\'],\r\n    ],\r\n    [\r\n        \'label\' => \'我的预约\',\r\n        \'url\'   => [\'/my-appointment\'],\r\n    ],\r\n    [\r\n        \'label\' => \'个人资料\',\r\n        \'url\'   => [\'/profile\'],\r\n    ],\r\n    [\r\n        \'label\' => \'个人中心\',\r\n        \'url\'   => [\'/me\'],\r\n    ],\r\n    [\r\n        \'label\' => \'注册\',\r\n        \'url\'   => [\'/register\'],\r\n    ],\r\n    [\r\n        \'label\' => \'登录\',\r\n        \'url\'   => [\'/login\'],\r\n    ],\r\n];\r\n?>\r\n\r\n<div class=\"ui-my-patient-list\">\r\n    <div class=\"list-wrapper mb-20\">\r\n        <?php foreach ($items as $item): ?>\r\n            <div class=\"ui-form-item ui-form-item-link ui-border-b\">\r\n                <?= Html::a($item[\'label\'], $item[\'url\']); ?>\r\n            </div>\r\n        <?php endforeach; ?>\r\n    </div>\r\n</div>\r\n',0),
	(5,'就诊人添加、编辑表单','page.patient-create-update-form','<?php\r\nuse common\\utils\\ListGenerator;\r\nuse yii\\helpers\\Html;\r\n$selectOptions = [\r\n    \'template\' => \"{label}\\n<div class=\'ui-select\'>{input}</div>\",\r\n    \'options\'  => [\r\n        \'class\' => \'ui-form-item ui-border-b\',\r\n    ],\r\n];\r\n$inputOptions  = [\r\n    \'template\' => \"{label}\\n{input}\",\r\n    \'options\' => [\r\n        \'class\' => \'ui-form-item ui-border-b\',\r\n    ],\r\n];\r\n?>\r\n<style>.help-block{display:none;}</style>\r\n<div class=\"ui-form ui-border-t\">\r\n    <?php $form = \\yii\\widgets\\ActiveForm::begin([\'id\' => \'form\']) ?>\r\n\r\n    <?= $form->field($model, \"name\", $inputOptions)\r\n             ->hint(false)\r\n             ->textInput([\'placeholder\' => \'真实姓名\',])\r\n    ?>\r\n    <?= $form->field($model, \"sex\", $selectOptions)\r\n             ->hint(false)\r\n             ->dropDownList([\'女\', \'男\'])\r\n    ?>\r\n    <?= $form->field($model, \"phone\", $inputOptions)\r\n             ->hint(false)\r\n             ->textInput([\'pattern\' => \'\\d*\', \'placeholder\' => \"联系手机号\", \'type\' => \'tel\'])\r\n    ?>\r\n\r\n    <div class=\"ui-form-item ui-border-b\">\r\n        <?= Html::activeLabel($model, \"birth\") ?>\r\n        <div class=\"ui-select-group\">\r\n            <div class=\"ui-select\">\r\n                <?= Html::activeDropDownList($model, \"birthYear\", ListGenerator::year()) ?>\r\n            </div>\r\n            <div class=\"ui-select\">\r\n                <?= Html::activeDropDownList($model, \"birthMonth\", ListGenerator::month()) ?>\r\n            </div>\r\n            <div class=\"ui-select\">\r\n                <?= Html::activeDropDownList($model, \"birthDay\", ListGenerator::day()) ?>\r\n            </div>\r\n        </div>\r\n    </div>\r\n\r\n    <?= $form->field($model, \"identify\", $inputOptions)\r\n             ->hint(false)\r\n             ->textInput([\'pattern\' => \'\\d*\', \'placeholder\' => \"18或15位身份证号\", \'type\' => \'tel\'])\r\n    ?>\r\n\r\n    <?php \\yii\\widgets\\ActiveForm::end(); ?>\r\n</div>\r\n\r\n<script>\r\n    $(\"body\").on(\"tap\", \"#action-btn-save\", function (e) {\r\n        e.preventDefault();\r\n        $(\"#form\").submit();\r\n    });\r\n    \r\n     $(\'#form\').on(\'afterValidate\', function (event, messages, errorAttributes) {\r\n         for (field in messages){\r\n             if (messages[field].length > 0){\r\n                 msgTip(messages[field][0])\r\n             }\r\n         }\r\n     });\r\n</script>',0),
	(6,'导航条','element.navbar','<header class=\"ui-header ui-header-stable ui-navbar ui-border-b\">\r\n    <?php if ($this->showGoBack): ?>\r\n        <a class=\"ui-icon-return\" href=\"<?=$this->goBackTo?>\"></a>\r\n    <?php endif; ?>\r\n    <h1><?= $this->title ?></h1>\r\n    <?php if ($this->showSave): ?>\r\n        <button class=\"ui-btn ui-btn-main\" id=\'action-btn-save\'>保存</button>\r\n    <?php endif; ?>\r\n</header>\r\n',0),
	(7,'Tab选择','element.tabbar','<?php\r\nuse yii\\helpers\\Html;\r\nuse yii\\helpers\\Url;\r\n\r\n\r\n$tabs = \\common\\utils\\Cache::getOrSet(\"data.site.tabbar\", function(){\r\n    $indentList = \\common\\models\\LinkGroup::getLinkItems(\"site.tabbar\");\r\n    \r\n    $items = [];\r\n    foreach($indentList as $item){\r\n        $items[]=[\r\n            \'url\'         => $item->getUrl(),\r\n            \'label\'       => $item->name,\r\n            \'icon\'        => $item->getOption(\"icon\"),\r\n            \'active_icon\' => $item->getOption(\"active_icon\"),\r\n        ];\r\n    }\r\n    \r\n    return $items;\r\n});\r\n?>\r\n\r\n<footer class=\"ui-footer ui-footer-stable ui-border-t ui-footer-tabbar\">\r\n    <ul class=\"ui-tiled\">\r\n        <?php foreach ($tabs as $tabItem): ?>\r\n            <li class=\"tab-item <?= ($tabItem[\'url\']== $_SERVER[\'REQUEST_URI\']) ? \"active\" : \'\' ?>\">\r\n                <a href=\"<?= Url::to($tabItem[\'url\']) ?>\">\r\n                    <div class=\"icon\">\r\n                        <?= Html::img(($tabItem[\'url\']== $_SERVER[\'REQUEST_URI\'])  ? $tabItem[\'active_icon\'] : $tabItem[\'icon\']) ?>\r\n                    </div>\r\n                    <div class=\"label\">\r\n                        <p><?= $tabItem[\'label\'] ?></p>\r\n                    </div>\r\n                </a>\r\n            </li>\r\n        <?php endforeach; ?>\r\n    </ul>\r\n</footer>',0),
	(8,'在线咨询：医生列表','page.doctor-appointment-ask-list','{% index.search-box %}\r\n{% element.doctor_filter %}\r\n\r\n<div class=\"row ui-page-appointment\">\r\n    <ul class=\"ui-list ui-border-tb\">\r\n        <?php if (empty($items)){ ?>\r\n        <li>\r\n            <div style=\"width:100%\" class=\"mtb-20 ui-txt-size-18 ui-align-center\">对不起，没有找到内容</div>\r\n            </li>\r\n        <?php }?>\r\n        <?php foreach ($items as $item): ?>\r\n            <?php\r\n            $url = [\'/doctor\', \'id\' => $item->id];\r\n            ?>\r\n            <li class=\"doctor-list\">\r\n                <a href=\"<?= \\yii\\helpers\\Url::to($url) ?>\" class=\"ui-avatar\">\r\n                    <?= \\yii\\helpers\\Html::img($item->head_image) ?>\r\n                </a>\r\n                <div class=\"ui-list-info ui-border-t\">\r\n                    <div class=\"ui-row-flex\">\r\n                        <div class=\"ui-col doctor-info\">\r\n                            <h4 class=\"ui-nowrap mb-5\">\r\n                                <?= \\yii\\helpers\\Html::a($item->name, $url, [\'class\' => \'doctor-name\']) ?>\r\n                                <span class=\"subtitle\"><?= $item->levelModel->level_name ?></span>\r\n                            </h4>\r\n                            <div class=\"ui-label-list ui-no-margin mb-5\">\r\n                                <span class=\"ui-label-head\">擅长:</span>\r\n\r\n                                <?php foreach ($item->departments as $department): ?>\r\n                                    <label class=\"ui-label-s\"><?= $department->department->name ?></label>\r\n                                <?php endforeach; ?>\r\n                            </div>\r\n                            <p class=\"ui-desc\">\r\n                                <span>\r\n                                    评分：\r\n                                    <span class=\"count\"><?=\\common\\models\\PatientFeedback::getDoctorMark($item->id)?></span>\r\n                                    |\r\n                                </span>\r\n\r\n                                <span>\r\n                                    评价：\r\n                                    <span class=\"count\"><?=\\common\\models\\PatientFeedback::count([\"doctor_id\"=>$item->id])?></span>\r\n                                    |\r\n                                </span>\r\n                                <span>\r\n                                    接诊：\r\n                                    <span class=\"count\"><?=\\common\\models\\DoctorAppointment::count([\"doctor_id\"=>$item->id,\"status\"=>\"0\"])?></span>\r\n                                </span>\r\n                            </p>\r\n                        </div>\r\n                        <div class=\"ui-flex ui-flex-ver ui-flex-pack-center ui-flex-align-start ui-btn-group-wrapper\">\r\n                            <div class=\"ui-txt-center mb-20 price\">&yen;<?=$item->ask_price?></div>\r\n                            <a href=\"<?= \\yii\\helpers\\Url::to([\"/ask\", \"id\" => $item->id]) ?>\" class=\"ui-btn-s\">在线问诊</a>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </li>\r\n        <?php endforeach; ?>\r\n    </ul>\r\n</div>\r\n',0),
	(9,'就诊人列表提示信息','element.patient-list.alert','<div class=\"ui-alert-tips\">\r\n    <i><img src=\"/images/icon-alert.png\" /></i><span>每个人最多添加10个就诊人\r\n</div>',0),
	(10,'个人中心-链接列表','element.me.link-list','<?php\r\n\r\n$items = \\common\\utils\\Cache::getOrSet(\"data.me.link-list\", function(){\r\n    $indentList = \\common\\models\\LinkGroup::getLinkItems(\"me.link-list\");\r\n    \r\n    $items = [];\r\n    foreach($indentList as $item){\r\n        $items[]=[\r\n            \'url\'         => $item->getUrl(),\r\n            \'label\'       => $item->name,\r\n        ];\r\n    }\r\n    \r\n    return $items;\r\n});\r\n?>\r\n<section class=\"ui-page-me-service-list mb-20\">\r\n    <?php foreach ($items as $item): ?>\r\n        <div class=\"ui-arrowlink ui-border-b\">\r\n            <?= \\yii\\helpers\\Html::a($item[\'label\'], $item[\'url\']) ?>\r\n        </div>\r\n    <?php endforeach; ?>\r\n</section>',4003),
	(11,'个人中心 - 两格列表','element.me.2-grid','<?php\r\n$items = \\common\\utils\\Cache::getOrSet(\"data.me.iconbar\", function(){\r\n    $indentList = \\common\\models\\LinkGroup::getLinkItems(\"me.iconbar\");\r\n    \r\n    $items = [];\r\n    foreach($indentList as $item){\r\n        $items[]=[\r\n            \'label\'       => $item->name,\r\n            \'url\'       => $item->getOption(\"url\"),\r\n            \'value\'       => call_user_func_array($item->getOption(\"callback\"),[]),\r\n        ];\r\n    }\r\n    \r\n    return $items;\r\n});\r\n?>\r\n\r\n<section class=\"ui-page-me-action-icon mb-20\">\r\n    <ul class=\"ui-tiled\">\r\n        <?php foreach ($items as $item): ?>\r\n            <li>\r\n                <a href=\"<?=\\yii\\helpers\\Url::to($item[\'url\']);?>\">\r\n                    <div class=\"img-wrapper\"><?=$item[\'value\']?></div>\r\n                    <div><span><?=$item[\'label\']?></span></div>\r\n                </a>\r\n            </li>\r\n        <?php endforeach; ?>\r\n    </ul>\r\n</section>',4002),
	(12,'个人中心-头像信息','element.me.head-info','<section class=\"ui-page-me-banner mb-20\">\r\n    <div class=\"ui-backdrop-filter\"></div>\r\n\r\n    <div class=\"head-wrapper\">\r\n        <?=\\yii\\helpers\\Html::img($model->head_image)?>\r\n    </div>\r\n    <div class=\"user-summary\">\r\n        <div class=\"user-id\">\r\n            <?= $model->nickname ?>\r\n        </div>\r\n        <div class=\"user-score\">\r\n            我的积分：<?=$model->coin->coin?:0?> \r\n        </div>\r\n    </div>\r\n</section>',4001),
	(13,'在线咨询表单','page.patient-ask-form','<?php\r\nuse yii\\helpers\\Html;\r\n$items = \\common\\models\\MyPatient::getList(\\common\\utils\\UserSession::getId());\r\n\r\n$doctorID = \\common\\utils\\Request::input(\"id\");\r\n$patientID = \\common\\utils\\Request::input(\"patient\");\r\n$userID    = \\common\\utils\\UserSession::getId();\r\n?>\r\n\r\n<?php $form = \\yii\\widgets\\ActiveForm::begin([\'options\'=>[\'id\'=>\'form\']]); ?>\r\n<div class=\"row ui-form ui-border-t pb-20\">\r\n    <div class=\"ui-form-item  ui-form-item-link ui-border-b\">\r\n        <label>就诊人</label>\r\n        <?php\r\n            $patientUrl =  \\yii\\helpers\\Url::to([\r\n                \'patient/index\',\r\n                \'id\'=>$doctorID,\r\n                \'patient\'=>$patientID,\r\n                \'mode\'=> \"select\",\r\n            ]);\r\n            \r\n            echo Html::a(\\common\\models\\MyPatient::getPatient($patientID, $userID),$patientUrl,[\r\n                \'class\'=>\'ui-block ml-100 ui-txt-info\'\r\n            ]);\r\n        ?>\r\n    </div>\r\n\r\n    <div class=\"ui-row-container mt-20 mb-20\">\r\n        <label class=\"ui-block\">病情描述</label>\r\n        <div class=\"ui-block-textarea-wrapper\">\r\n            <?= Html::activeTextarea($model, \"description\", [\r\n                \'class\'       => \'ui-block-textarea\',\r\n                \'rows\'        => 5,\r\n                \'placeholder\' => \"请对您的病情进行描述\",\r\n            ]) ?>\r\n        </div>\r\n    </div>\r\n\r\n    <div class=\"ui-row-container mt-20 mb-20\">\r\n        <?= \\rogeecn\\SimpleAjaxUploader\\MultipleImage::widget([\r\n            \'model\'             => $model,\r\n            \'attribute\'         => \'images\',\r\n            \'style\'             => false,\r\n            \'uploadIconOptions\' => [\r\n                \'class\' => \'ui-icon-add\',\r\n            ],\r\n        ]) ?>\r\n        <p class=\"ui-txt-muted\">\r\n            请上传您的舌苔照、病历部位、病历、处方单、检查图片等诊断材料。\r\n        </p>\r\n    </div>\r\n</div>\r\n\r\n<div class=\"ui-patient-ask-form ui-bg-white mt-20\">\r\n    <div class=\"ui-ask-price-container\">&yen;<?=$doctorModel->ask_price;?></div>\r\n    <input type=\"submit\" value=\"确定\" onclick=\"checkData\" class=\"ui-btn-lg\"/>\r\n</div>\r\n<?php \\yii\\widgets\\ActiveForm::end() ?>\r\n\r\n\r\n<script>\r\n\r\nfunction checkData(){\r\n    if ($(\"#patientask-description\").val().length<5){\r\n        msgTip(\"请最少输入5个字符\");\r\n        return false\r\n    }\r\n    return true;\r\n}\r\n\r\n    $(function(){\r\n        $(\'#form\').on(\'afterValidate\', function (event, messages, errorAttributes) {\r\n         for (field in messages){\r\n             if (messages[field].length > 0){\r\n                 msgTip(messages[field][0])\r\n             }\r\n         }\r\n     });\r\n    })\r\n</script>',1002),
	(14,'我的历史咨询列表','page.my-ask-history-list','<div class=\"my-ask-list\">\r\n    <section class=\"ui-alert-tips\">\r\n        <i><img src=\"/images/icon-alert.png\" /></i>\r\n        <span>温馨提示：关于取消预约须知，<a href=\"/appointment/cancel\">点击查看</a></span>\r\n    </section>\r\n\r\n    <?php foreach ($models as $model): ?>\r\n        <section class=\"ui-panel mb-20 mt-20\" data-id=\"<?= $model->id ?>\">\r\n            <div class=\"ui-panel-heading ui-border-b flex-show\">\r\n                <div class=\"title\">\r\n                    <a class=\"head-info\">\r\n                        <?= \\yii\\helpers\\Html::img($model->doctor->head_image) ?>\r\n                    </a>\r\n                    <?= $model->doctor->name ?>&nbsp;\r\n                    <?= $model->doctor->levelModel->level_name ?>\r\n                </div>\r\n                <div class=\"status\">\r\n                    <?php\r\n                    if ($model->reply_at>0 && strtotime(\"+48 hour\", $model->reply_at) < time()) {\r\n                        echo \\yii\\helpers\\Html::tag(\"span\", \"已结束\");\r\n                    } else {\r\n                        if ($model->getIsPayed()) {\r\n                            $txt = empty($model->reply_at) ? \"未回复\" : \"问诊中\";\r\n                            echo \\yii\\helpers\\Html::tag(\"span\", $txt);\r\n                        } else {\r\n                            echo \\yii\\helpers\\Html::a(\"立即支付\",[\'/pay/index\',\'id\'=>$model->getOrderID()]);\r\n                        }\r\n                    } ?>\r\n                </div>\r\n            </div>\r\n\r\n            <div class=\"ui-panel-body\">\r\n                <?= \\yii\\helpers\\Html::encode($model->description) ?>\r\n            </div>\r\n\r\n            <?php if (!empty($model->images)): ?>\r\n                <div class=\"ui-panel-body\">\r\n                    <ul class=\"image-list\">\r\n                        <?php foreach ($model->getImageList() as $imageUrl): ?>\r\n                            <li>\r\n                                <?= \\yii\\helpers\\Html::img($imageUrl) ?>\r\n                            </li>\r\n                        <?php endforeach; ?>\r\n                    </ul>\r\n                </div>\r\n            <?php endif; ?>\r\n\r\n            <div class=\"ui-panel-body ui-txt-info\">\r\n                <?= date(\"Y-m-d H:i:s\", $model->created_at) ?>\r\n            </div>\r\n\r\n            <div class=\"ui-panel-body ui-border-t price-wrapper\">\r\n                <div class=\"price-info\">\r\n                    问诊费：<span class=\"price-show\">&yen; <?= $model->doctor->ask_price ?></span>\r\n                </div>\r\n                <div class=\"btn-list\">\r\n                    <?php\r\n                    if ($model->reply_at > 0) {\r\n                        echo \\yii\\helpers\\Html::a(\"查看回复\", [\"/ask/reply\", \'id\' => $model->id], [\'class\' => \'ui-btn-s ui-btn-primary\']);\r\n                    }\r\n                    ?>\r\n                    <?= \\yii\\helpers\\Html::a(\"预约挂号\", [\"/doctor/index\", \'id\' => $model->doctor_id], [\'class\' => \'ui-btn-s ui-btn-go-appointment\']) ?>\r\n                </div>\r\n            </div>\r\n        </section>\r\n    <?php endforeach; ?>\r\n</div>',0),
	(15,'医生详情-底部按钮','element.doctor.bottom-buttons','<footer class=\"ui-footer ui-footer-stable ui-doctor-footer\">\r\n    <ul class=\"ui-tiled\">\r\n        <li class=\"tab-item appointment\">\r\n            <a href=\"<?= \\yii\\helpers\\Url::to([\'/ask\',\'id\'=>$model->id]) ?>\">在线咨询</a>\r\n        </li>\r\n        <li class=\"tab-item ask\">\r\n            <a href=\"<?= \\yii\\helpers\\Url::to([\"/doctor/order-date\",\"id\"=>$model->id]) ?>\">立即预约</a>\r\n        </li>\r\n    </ul>\r\n</footer>',2001),
	(16,'医生详情-医生头像信息','element.doctor.head-info','    <section class=\"ui-doctor-profile\">\r\n        <header class=\"ui-header ui-navbar ui-doctor-navbar\">\r\n            <i class=\"ui-icon-return\" onclick=\"history.back()\"></i>\r\n            <h1>医生主页</h1>\r\n        </header>\r\n\r\n        <div class=\"ui-doctor-description\">\r\n            <div class=\"doctor-head-img\">\r\n                <?= \\yii\\helpers\\Html::img($model->head_image) ?>\r\n            </div>\r\n            <p class=\"doctor-name ui-font-kaiti\">\r\n                <?= sprintf(\"%s&nbsp;%s\", $model->name, $model->levelModel->level_name); ?>\r\n            </p>\r\n        </div>\r\n\r\n        <div class=\"ui-doctor-information\">\r\n            <ul class=\"ui-tiled\">\r\n                 <li>\r\n                    <span class=\"title\">接诊量</span>\r\n                    <p class=\"count\"><?=\\common\\models\\DoctorAppointment::count([\"doctor_id\"=>$model->id,\"status\"=>\"0\"])?></p>\r\n                </li>\r\n                <li>\r\n                    <span class=\"title\">口碑</span>\r\n                    <p class=\"count\"><?=\\common\\models\\PatientFeedback::getDoctorMark($model->id)?></p>\r\n                </li>\r\n                <li>\r\n                    <span class=\"title\">评论数</span>\r\n                    <p class=\"count\"><?=\\common\\models\\PatientFeedback::count([\"doctor_id\"=>$model->id])?></p>\r\n                </li>\r\n            </ul>\r\n        </div>\r\n    </section>',2002),
	(17,'医生详情-就诊信息','element.doctor.patient-service-info','<section class=\"ui-panel ui-doctor-appointment-tab\">\r\n    <div class=\"ui-panel-heading\">\r\n        <ul class=\"ui-tiled ui-tab-list\">\r\n            <li data-id=\"0\" class=\"active\"><i><img src=\"/images/doctor-switch-0.png\"/></i>预约挂号</li>\r\n            <li data-id=\"1\"><i><img src=\"/images/doctor-switch-1.png\"/></i>在线咨询</li>\r\n        </ul>\r\n    </div>\r\n\r\n    <div class=\"ui-panel-body\">\r\n        <div class=\"ui-tab-item-content ui-tab-item-0 ui-hide ui-show\">\r\n            <ul class=\"ui-doctor-appointment-list\">\r\n                <?php\r\n                $serviceDate   = \\common\\models\\DoctorServiceTime::getAllRecentServiceTimeDateList($model->id, false);\r\n                $showItemIndex = 0;\r\n                foreach ($serviceDate as $dateKey => $date) {\r\n                    $showItem = $showItemIndex == 0;\r\n                    $showItemIndex++;\r\n                    ?>\r\n                    <li class=\"ui-border-b\">\r\n                        <span class=\"time\"><?= $date ?></span>\r\n                        <span class=\"location\">汉典中医院</span>\r\n                        <span class=\"price\">&yen; <?= $model->doctorServiceTime->price ?></span>\r\n                        <span class=\"btn-wrapper\">\r\n                            <?= \\yii\\helpers\\Html::button(\"预约\", [\r\n                                \'data-date\'   => $dateKey,\r\n                                \'data-doctor\' => $model->id,\r\n                                \'class\'       => \'ui-btn toggle-sidebar\',\r\n                            ]) ?>\r\n                        </span>\r\n                    </li>\r\n                    <?php\r\n                }\r\n                ?>\r\n\r\n            </ul>\r\n            <div class=\"ui-btn-show-all\" data-toggle=\"0\">查看全部排班</div>\r\n        </div>\r\n        <div class=\"ui-tab-item-content ui-tab-item-1 p-20 ui-hide \">\r\n            <div class=\"\">\r\n                <?php \r\n                if ($model->enable_ask) { \r\n                    ?>\r\n                    <p>填写病情资料（图文），专家在线回复</p>\r\n                    <p>48小时咨询医生本人，支持图片、文字。</p>\r\n                    \r\n                    <div style=\"margin-top: 20px;display:flex;justify-content: space-between;\">\r\n                    <?=\\yii\\helpers\\Html::tag(\"span\", \"医生咨询费用: \".$model->ask_price.\"元/次\",[\r\n                        \'style\'=>\'line-height: 30px\',\r\n                    ]);?>\r\n                    <span>\r\n                    <?=\\yii\\helpers\\Html::a(\"立即咨询\", [\"ask/index\", \"id\" => $model->id],[\r\n                        \'class\'=>\'ui-btn ui-btn-danger ui-btn-main\',\r\n                    ])?>\r\n                    </span>\r\n                    </div>\r\n                    <?php\r\n                } else {\r\n                    echo \"对不起，此医师暂未开通咨询功能！\";\r\n                } ?>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</section>\r\n\r\n<div id=\"sidebar\">\r\n    <div id=\"sidebar-wrapper\" class=\"sidebar-wrapper\">\r\n        <h1>请选择就诊时段</h1>\r\n        <div class=\"content\"></div>\r\n    </div>\r\n</div>\r\n\r\n<script>\r\n    $(function () {\r\n        $(\"body\").on(\"tap\", \".toggle-sidebar\", function () {\r\n            var data = {\r\n                date: $(this).attr(\"data-date\"),\r\n                doctor: $(this).attr(\"data-doctor\")\r\n            };\r\n\r\n            $(\"#sidebar-wrapper .content\").html(\"加载中...\");\r\n            $.get(\"/service-time/time-range\", data, function (data) {\r\n                $(\"#sidebar-wrapper .content\").html(data)\r\n            });\r\n        });\r\n        $(\"#sidebar\").simplerSidebar({\r\n            selectors: {\r\n                trigger: \".toggle-sidebar\",\r\n                quitter: \".close-sidebar\"\r\n            }\r\n        });\r\n\r\n        $(\"body\").on(\"tap\", \".ui-tab-item-content .ui-btn-show-all\", function () {\r\n            if ($(this).attr(\"data-toggle\") == 0) {\r\n                $(\".ui-doctor-appointment-list\").attr(\'style\', \"height: auto;\")\r\n                $(this).attr(\"data-toggle\", 1);\r\n                $(this).text(\"折叠全部排班\");\r\n            } else {\r\n                $(\".ui-doctor-appointment-list\").attr(\'style\', \"height: 60px;\")\r\n                $(this).attr(\"data-toggle\", 0);\r\n                $(this).text(\"查看全部排班\");\r\n            }\r\n        });\r\n\r\n        $(\"body\").on(\"tap\", \".ui-tab-list li\", function () {\r\n            var panelWrapper = $(this).closest(\".ui-panel\");\r\n            if ($(this).hasClass(\"active\")) {\r\n                return;\r\n            }\r\n\r\n            $(panelWrapper).find(\".ui-panel-heading li\").removeClass(\"active\");\r\n            $(this).addClass(\"active\");\r\n\r\n            var _tabID = $(this).attr(\"data-id\");\r\n            $(panelWrapper).find(\".ui-panel-body .ui-tab-item-content\").removeClass(\"ui-show\");\r\n            $(panelWrapper).find(\".ui-panel-body .ui-tab-item-\" + _tabID).addClass(\"ui-show\");\r\n        });\r\n    })\r\n</script>',2003),
	(18,'医生详情-专业擅长','element.doctor.good-at','    <section class=\"mb-20 ui-panel\">\r\n        <div class=\"ui-panel-heading flex-show\">\r\n            <div class=\"title\">专业擅长</div>\r\n            <div class=\"extend ui-arrowlink\">展开</div>\r\n        </div>\r\n        <div class=\"ui-panel-body data-detail ui-hide\">\r\n            <div class=\"ui-label-list ui-doctor-label\">\r\n                <?php\r\n                foreach ($model->tags as $tag) {\r\n                    echo \\yii\\helpers\\Html::tag(\"label\",$tag->name, [\'class\' => \'ui-label-s\']);\r\n                    echo \"\\n\";\r\n                }\r\n                ?>\r\n            </div>\r\n        </div>\r\n        <div class=\"ui-panel-body data-summary ui-show\">\r\n            <div class=\"ui-label-list ui-doctor-label\">\r\n                <?php\r\n                $index = 0;\r\n                foreach ($model->tags as $tag) {\r\n                    if ($index > 5) {\r\n                        break;\r\n                    }\r\n                    $index++;\r\n                    echo \\yii\\helpers\\Html::tag(\"label\",$tag->name, [\'class\' => \'ui-label-s\']);\r\n                    echo \"\\n\";\r\n                }\r\n                ?>\r\n            </div>\r\n        </div>\r\n    </section>\r\n',2004),
	(19,'医生详情-信息描述','element.doctor.description','<section class=\"ui-panel mb-20\">\r\n    <div class=\"ui-panel-heading flex-show\">\r\n        <div class=\"title\">职业医师</div>\r\n        <div class=\"extend ui-arrowlink\">展开</div>\r\n    </div>\r\n    <div class=\"ui-panel-body ui-txt-info ui-txt-size-14 ui-show\">\r\n        <?= $model->summary ?>\r\n    </div>\r\n    <div class=\"ui-panel-body ui-txt-info ui-txt-size-14 ui-hide\">\r\n        <?= $model->introduce ?>\r\n    </div>\r\n</section>',2005),
	(20,'医生详情-患者评价','element.doctor.patient-feedback','<?php\r\n/** @var \\common\\models\\PatientFeedback $feedbackModel */\r\n$feedbackModel = \\common\\models\\PatientFeedback::getLatestFeedbackToDoctor($model->id);\r\n\r\nif ($feedbackModel):\r\n?>\r\n<section class=\"ui-panel mb-20\">\r\n    <div class=\"ui-panel-heading\">\r\n        <div class=\"title\">患者评价</div>\r\n    </div>\r\n    <div class=\"ui-panel-body ui-patient-feedback\">\r\n        <div class=\"ui-patient-info ui-flex ui-justify-flex ui-flex-align-center\">\r\n            <div class=\"ui-head-info\">\r\n                <div class=\" ui-flex ui-flex-align-center\">\r\n                    <div class=\"ui-avatar-s\">\r\n                        <img src=\"<?= $feedbackModel->appointment->user->head_image ?>\" alt=\"\">\r\n                    </div>\r\n                    <div class=\"ui-patient-name\">\r\n                        <?= $feedbackModel->maskPatientName() ?>\r\n                    </div>\r\n                    <div class=\"ui-patient-status\">已就诊</div>\r\n                </div>\r\n            </div>\r\n\r\n            <div class=\"ui-patient-datetime ui-txt-info\"><?= date(\"Y-m-d\", $feedbackModel->created_at) ?></div>\r\n        </div>\r\n        <div class=\"ui-patient-evaluate  ui-flex ui-flex-align-center\">\r\n            <?php for ($i = 0; $i < $feedbackModel->mark; $i++): ?>\r\n                <i class=\"ui-icon-star\"></i>\r\n            <?php endfor; ?>\r\n        </div>\r\n\r\n        <div class=\"ui-feedback ui-txt-info ui-txt-size-14\">\r\n            <?= $feedbackModel->content; ?>\r\n        </div>\r\n        <div class=\"ui-patient-btn-view-all\">\r\n            <?= \\yii\\helpers\\Html::a(\"查看全部评价\", [\'/doctor/feedback\', \'id\' => $model->id], [\'class\' => \'ui-btn-lg\']) ?>\r\n        </div>\r\n    </div>\r\n</section>\r\n\r\n<?php endif; ?>',2006),
	(21,'医生详情-同科室医生推荐','element.doctor.same-department-doctor-recommend','<section class=\"ui-panel mb-20 ui-doctor-recommend\">\r\n    <div class=\"ui-panel-heading flex-show\">\r\n        <div class=\"title\">同科室医生推荐</div>\r\n        <div class=\"extend ui-arrowlink\">展开</div>\r\n    </div>\r\n    <div class=\"ui-panel-body\">\r\n        <ul class=\"list-group\">\r\n            <?php foreach ($model->getSameDepartmentDoctors() as $doctor): ?>\r\n                <li>\r\n                    <div class=\"head\"><?= \\yii\\helpers\\Html::img($doctor->head_image) ?></div>\r\n                    <div class=\"information ui-txt-size-14\">\r\n                        <div><?= $doctor->name ?></div>\r\n                        <div class=\"ui-txt-info\"><?= $doctor->levelModel->level_name ?></div>\r\n                        <div class=\"ui-txt-info\"><?= $doctor->departmentString() ?></div>\r\n                    </div>\r\n                </li>\r\n            <?php endforeach; ?>\r\n        </ul>\r\n    </div>\r\n</section>',2007),
	(22,'医生详情','page.doctor','<section class=\"ui-container\">\r\n    {% element.doctor.head-info %}\r\n    {% element.doctor.patient-service-info %}\r\n    {% element.doctor.good-at %}\r\n    {% element.doctor.description %}\r\n    {% element.doctor.patient-feedback %}\r\n    {% element.doctor.same-department-doctor-recommend %}\r\n</section>\r\n\r\n<script>\r\n    $(function(){\r\n        $(\"body\").on(\"click\", \".ui-panel .extend\", function(){\r\n            var _txt_fold = \"折叠\";\r\n            var _txt_expand = \"展开\";\r\n\r\n            if ($(this).text() == _txt_fold){\r\n                $(this).text(_txt_expand);\r\n            }else{\r\n                $(this).text(_txt_fold);\r\n            }\r\n            \r\n            $(this).closest(\".ui-panel\").find(\".ui-show\").toggle();\r\n            $(this).closest(\".ui-panel\").find(\".ui-hide\").toggle();\r\n        });  \r\n    })\r\n</script>',2000),
	(23,'医生预约时间选择','page.doctor-appointment.date-picker','<div class=\"ui-align-center mtb-20\">\r\n    <?= sprintf(\"仅开放%d天内的门诊预约\", \\common\\models\\DoctorServiceTime::getMaxTimeLong($model->id)); ?>\r\n\r\n</div>\r\n\r\n<div class=\"ui-panel pt-20 pb-20 ui-date-selector\">\r\n    <ul class=\"ui-grid-halve\">\r\n        <?php\r\n        $serviceDate = \\common\\models\\DoctorServiceTime::getAllRecentServiceTimeDateList($model->id);\r\n        foreach ($serviceDate as $date => $dateString) {\r\n            $dateWrapper = \\yii\\helpers\\Html::a($dateString, [\"/doctor/order\", \'date\' => $date, \'id\' => $model->id]);\r\n            echo \\yii\\helpers\\Html::tag(\"li\", $dateWrapper);\r\n        }\r\n        ?>\r\n    </ul>\r\n</div>',0),
	(24,'预约需知','page.doctor-appointment.term','<div class=\"ui-panel p-20\">\r\n    <p>由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。</p>\r\n    <p>由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。</p>\r\n    <p>由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。</p>\r\n    <p>由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。</p>\r\n    <p>由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。</p>\r\n    <p>由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。</p>\r\n    <p>由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。</p>\r\n</div>',0),
	(25,'个人中心','page.me','{% element.me.head-info %}\r\n{% element.me.2-grid %}\r\n{% element.me.alert-tip %}\r\n{% element.me.link-list %}',4000),
	(26,'首页','page.index','{% index.search-box %}\r\n{% index.carousel %}\r\n{% index.9-grids %}\r\n',0),
	(27,'确认订单-健康券','element.order.healthy-ticket','<div class=\"ui-form ui-border-t mb-20\">\r\n    <div class=\"ui-form-item ui-border-b\">\r\n        <label>健康券</label>\r\n        <div class=\"ui-select\">\r\n            <select>\r\n                <option>无</option>\r\n            </select>\r\n        </div>\r\n    </div>\r\n</div>',0),
	(28,'确认订单-虚拟货币','element.order.healthy-coin','<div class=\"ui-form ui-border-t mb-20\">\r\n    <div class=\"ui-form-item ui-border-b\">\r\n        <label>固币余额</label>\r\n        <input type=\"text\" value=\"0\" readonly>\r\n    </div>\r\n</div>',0),
	(29,'确认订单-预约需知链接','element.order.appointment-term-link','<div class=\"ui-container\">\r\n    <div class=\"ui-txt-info p-lr-15\">\r\n        预约前请认真阅读<a href=\"/doctor/appointment-term\">《预约需知》</a>\r\n    </div>\r\n</div>',0),
	(30,'医生预约：确认订单-支付通道选择','element.order.pay-channel-selector','<div class=\"ui-form ui-border-t mb-20\">\r\n    <div class=\"ui-form-item ui-border-b\">\r\n        <label>支付方式</label>\r\n        <div class=\"ui-select\">\r\n            <?php\r\n            $payChannel = \\common\\models\\Order::getPayChannel([\r\n                \\common\\models\\Order::CHANNEL_WECHATPAY,\r\n                \\common\\models\\Order::CHANNEL_OFFLINE,\r\n            ]);\r\n            echo \\yii\\helpers\\Html::dropDownList(\"data[pay_channel]\", null,$payChannel);\r\n            ?>\r\n        </div>\r\n    </div>\r\n</div>',3005),
	(31,'医生预约：确认订单-就诊人选择','element.order.patient-selector','<div class=\"ui-form ui-border-t mb-20 mt-20\">\r\n    <div class=\"ui-form-item  ui-form-item-link ui-border-b\">\r\n        <label>就诊人</label>\r\n        <!--<div class=\"ui-select\">\r\n            <?php\r\n            //$myPatientList = \\common\\models\\MyPatient::getList(\\common\\utils\\UserSession::getId());\r\n            //echo \\yii\\helpers\\Html::dropDownList(\"data[patient]\", null, $myPatientList);\r\n            ?>\r\n        </div>-->\r\n        <?php\r\n            $patientUrl =  \\yii\\helpers\\Url::to([\r\n                \'patient/index\',\r\n                \'id\'=>$doctorModel->id,\r\n                \'patient\'=>$patientModel->id,\r\n                \'time\'=>$time,\r\n                \'date\'=>$date,\r\n                \'mode\'=> \"select\",\r\n                \'from\'=> \"doctor\",\r\n            ]);\r\n            \r\n            $patientInfo = $patientModel?$patientModel->getInfo():\"&nbsp;\";\r\n            echo \\yii\\helpers\\Html::a($patientInfo,$patientUrl,[\r\n                \'class\'=>\'ui-block ml-100 ui-txt-info\'\r\n            ]);\r\n        ?>\r\n    </div>\r\n</div>',3001),
	(32,'医生预约：确认订单-挂号金额','element.order.order-price','<div class=\"ui-form ui-border-t mb-20\">\r\n    <div class=\"ui-form-item ui-border-b\">\r\n        <label>挂号金额</label>\r\n        <?php\r\n        $doctorServicePrice = \\common\\models\\DoctorServiceTime::getDoctorServicePrice($doctorModel->id);\r\n        echo \\yii\\helpers\\Html::textInput(\"price\", $doctorServicePrice, [\'readonly\' => true]);\r\n        ?>\r\n    </div>\r\n</div>',3004),
	(33,'医生预约：确认订单-挂号信息表单','element.order.doctor-info','<div class=\"ui-form ui-border-t mb-20\">\r\n    <div class=\"ui-form-item ui-border-b\">\r\n        <label>医生姓名</label>\r\n        <?= \\yii\\helpers\\Html::hiddenInput(\"data[doctor_id]\", $doctorModel->id) ?>\r\n        <?= \\yii\\helpers\\Html::textInput(\"doctor_name\", $doctorModel->name, [\'readonly\' => true]) ?>\r\n    </div>\r\n\r\n    <div class=\"ui-form-item ui-border-b\">\r\n        <label>就诊医院</label>\r\n        <?= \\yii\\helpers\\Html::textInput(\"hospital\", \"汉典中医医院\", [\'readonly\' => true]) ?>\r\n    </div>\r\n\r\n    <div class=\"ui-form-item ui-border-b\">\r\n        <label>就诊科室</label>\r\n        <div class=\"ui-select\">\r\n            <?php\r\n            $doctorDepartment = \\common\\models\\DoctorDepartment::getDepartmentList($doctorModel->id);\r\n            echo \\yii\\helpers\\Html::dropDownList(\"department\", null, $doctorDepartment);\r\n            ?>\r\n        </div>\r\n    </div>\r\n\r\n    <div class=\"ui-form-item ui-border-b\">\r\n        <label>就诊地址</label>\r\n        <?php $location = \\common\\models\\WebsiteConfig::getValueByKey(\"site.hospital.location\"); ?>\r\n        <?= \\yii\\helpers\\Html::textInput(\"location\", $location, [\'readonly\' => true]) ?>\r\n    </div>\r\n\r\n    <div class=\"ui-form-item ui-border-b\">\r\n        <label>预约时间</label>\r\n        <?= \\yii\\helpers\\Html::textInput(\"data[date]\", \r\n        \\common\\utils\\Request::input(\"date\").\" \".\\common\\utils\\Request::input(\"time\"),\r\n        [\'readonly\' => true]) ?>\r\n    </div>\r\n</div>',3002),
	(34,'医生预约：确认订单-底部确认','element.order.bottom-buttons','<?php\r\n$doctorServicePrice = \\common\\models\\DoctorServiceTime::getDoctorServicePrice($doctorModel->id);\r\n?>\r\n<div class=\"ui-form ui-border-t mb-20 mt-20\">\r\n    <div class=\"ui-form-item  ui-border-b\">\r\n        <label>订单金额</label>\r\n        <div class=\"ui-block ml-100 ui-txt-info\">&yen;<?= $doctorServicePrice ?></div>\r\n    </div>\r\n</div>\r\n\r\n<div class=\"m-20\">\r\n    <input class=\"ui-btn-lg ui-btn-main\" type=\"submit\" value=\"确认预约\"/>\r\n</div>',3003),
	(35,'医生预约：确认订单页面','page.order','<?php $form = \\yii\\widgets\\ActiveForm::begin([\'id\' => \'form\']) ?>\r\n\r\n{% element.order.patient-selector %}\r\n{% element.order.doctor-info %}\r\n\r\n{% element.order.bottom-buttons %}\r\n<!--\r\n{% element.order.pay-channel-selector %}\r\n{% element.order.healthy-ticket %}\r\n{% element.order.healthy-coin %}\r\n{% element.order.order-price %}\r\n{% element.order.appointment-term-link %}\r\n-->\r\n\r\n<?php \\yii\\widgets\\ActiveForm::end() ?>\r\n<script>\r\n    $(function () {\r\n        $(\"body\").on(\"click\", \"#order-submit\", function () {\r\n            if (!<?=\\common\\utils\\Request::input(\"patient\")?>){\r\n                msgTip(\"请选择就诊人！\");\r\n                return false;\r\n            }\r\n            if (!confirm(\"请确认预约信息是否正确？\")) {\r\n                return false;\r\n            }\r\n\r\n            $(\"#form\").submit();\r\n        });\r\n    })\r\n</script>\r\n',3000),
	(36,'就诊人列表-选择模式','page.patient-list-mode-select','<?php\r\n    $currentPatientID = \\common\\utils\\Request::input(\"patient\");\r\n    if (is_null($currentPatientID)){\r\n        $defaultPatientModel = \\common\\models\\MyPatient::getPatientModel(null,\\common\\utils\\UserSession::getId());\r\n        if ($defaultPatientModel){\r\n            $currentPatientID = $defaultPatientModel->id;\r\n        }\r\n    }\r\n?>\r\n<div class=\"ui-my-patient-list\">\r\n    {% element.patient-list.alert %}\r\n\r\n    <div class=\"list-wrapper mb-20\">\r\n        <?php foreach ($models as $model): ?>\r\n            <div class=\"ui-panel mb-20 ui-user-info mode-select\">\r\n                <div class=\"select-btn ui-flex  ui-flex-align-center\">\r\n                    <?php \r\n                        \r\n                        if ($from == \"doctor\"){\r\n                            $url = [\r\n                                \"doctor/order\",\r\n                                \'patient\'=>$model->id,\r\n                                \'id\'=> \\common\\utils\\Request::input(\"id\"),\r\n                                \'date\'=> \\common\\utils\\Request::input(\"date\"),\r\n                                \'time\'=> \\common\\utils\\Request::input(\"time\"),\r\n                            ];\r\n                        }else{\r\n                            $url = [\r\n                                \"ask/index\",\r\n                                \'patient\'=>$model->id,\r\n                                \'id\'=> \\common\\utils\\Request::input(\"id\"),\r\n                            ];\r\n                        }\r\n                        \r\n                        $activeClass=\"\";\r\n                        if ($model->id == $currentPatientID){\r\n                            $activeClass=\"active\";\r\n                        }\r\n                        \r\n                        echo \\yii\\helpers\\Html::a(\"\",$url, [\r\n                            \'class\'=>\'ui-icon-checked-s \'.$activeClass,\r\n                        ])\r\n                    ?>\r\n                </div>\r\n                <div class=\"data-wrapper\">\r\n                    <div class=\"ui-panel-heading\">\r\n                        <div>\r\n                            <?=$model->name?>&nbsp;\r\n                            <?=$model->getSexDesc()?>&nbsp;\r\n                            <?=$model->getAge()?>\r\n                        </div>\r\n                        <div><?=$model->phone?></div>\r\n                    </div>\r\n                    <div class=\"ui-panel-body\">\r\n                        <?php if($model->default){?>\r\n                            <button class=\"ui-btn-s ui-btn-primary  action-set-default\" data-id=\"<?=$model->id?>\">默认联系人</button>\r\n                        <?php }else{?>\r\n                            <button class=\"ui-btn-s action-set-default\" data-id=\"<?=$model->id?>\">默认联系人</button>\r\n                        <?php }?>\r\n                        <button class=\"action-remove ui-btn-s ui-btn-danger\" data-id=\"<?=$model->id?>\">删除</button>\r\n                    </div>\r\n                </div>\r\n                <!--\r\n                <?= \\yii\\helpers\\Html::a($model->name, [\'/patient/update\', \'id\' => $model->id]) ?>\r\n                -->\r\n            </div>\r\n        <?php endforeach; ?>\r\n    </div>\r\n\r\n    <div class=\"ui-btn-wrapper\">\r\n        <?php\r\n        $btnUrl = [\r\n            \'/patient/create\',\r\n            \'mode\'=>\'select\',\r\n            \'id\'=> \\common\\utils\\Request::input(\"id\"),\r\n            \'patient\'=> \\common\\utils\\Request::input(\"patient\"),\r\n            ];\r\n        ?>\r\n        <?= \\yii\\helpers\\Html::a(\"添加新就诊人\", $btnUrl, [\r\n            \'class\' => \'ui-btn-lg ui-btn-add-new-patient\'\r\n        ]) ?>\r\n    </div>\r\n</div>\r\n\r\n<script>\r\n    $(function(){\r\n        // set default user\r\n        $(\"body\").on(\"click\",\".action-set-default\",function(){\r\n            $.get(\"/patient/set-default\",{id:$(this).attr(\"data-id\")},function(data){\r\n                $(\".ui-btn-s\").removeClass(\"ui-btn-primary\")\r\n                $(this).addClass(\"ui-btn-primary\")\r\n            }.bind(this));\r\n        })\r\n        \r\n        //  remove user\r\n        $(\"body\").on(\"click\",\".action-remove\",function(){\r\n            if (!confirm(\"确认删除此用户？\")){\r\n                return false;\r\n            }\r\n            \r\n            $.get(\"/patient/delete\",{id:$(this).attr(\"data-id\")},function(data){\r\n                $(this).closest(\".ui-panel\").remove();\r\n            });\r\n        });\r\n        \r\n        $(\"body\").on(\"tap\",\"i.ui-icon-checked-s\",function(){\r\n                        \r\n        })\r\n    })\r\n    \r\n</script>',1000),
	(37,'订单结算确认页面','page.order-pay','<section class=\"ui-notice ui-pay-order\">\r\n    <i></i>\r\n    <!--<p class=\"title\">恭喜您，预约成功！</p>-->\r\n\r\n    <p><?= $model->name ?></p>\r\n\r\n    <p class=\"price\">订单金额：<?= $model->getPriceYuan() ?></p>\r\n\r\n    <div class=\"ui-notice-btn\">\r\n        <button class=\"ui-btn-primary ui-btn-lg\" disabled id=\"action-btn-pay\">立即支付</button>\r\n    </div>\r\n</section>\r\n\r\n<script>\r\n    function onBridgeReady() {\r\n        $(\"#action-btn-pay\").removeAttr(\"disabled\");\r\n    }\r\n\r\n    if (typeof WeixinJSBridge == \"undefined\") {\r\n        if (document.addEventListener) {\r\n            document.addEventListener(\'WeixinJSBridgeReady\', onBridgeReady, false);\r\n        } else if (document.attachEvent) {\r\n            document.attachEvent(\'WeixinJSBridgeReady\', onBridgeReady);\r\n            document.attachEvent(\'onWeixinJSBridgeReady\', onBridgeReady);\r\n        }\r\n    } else {\r\n        onBridgeReady();\r\n    }\r\n\r\n    $(function () {\r\n        $(\"body\").on(\"click\", \"#action-btn-pay\", function () {\r\n            $.get(\"/order/pay-info\", {id: \"<?=$model->order_id?>\"}, function (data) {\r\n                if (data.code != 0) {\r\n                    alert(\"支付信息拉取失败,请重新支付！\");\r\n                    return false;\r\n                }\r\n\r\n                WeixinJSBridge.invoke(\r\n                    \'getBrandWCPayRequest\',\r\n                    data.data,\r\n                    function (res) {\r\n                        if (res.err_msg == \"get_brand_wcpay_request:ok\") {\r\n                            location.href = \"/appointment/mine\";\r\n                        } else {\r\n                            alert(\"支付失败， 请重新支付！\");\r\n                        }\r\n                    }\r\n                );\r\n            })\r\n        });\r\n    })\r\n</script>',0),
	(38,'错误页面','page.error','<section class=\"ui-notice\">\r\n    <i></i>\r\n    <p>出错了</p>\r\n    <div class=\"ui-notice-btn\">\r\n        <a href=\"/\" class=\"ui-btn-primary ui-btn-lg\">返回首页</a>\r\n    </div>\r\n</section>',0),
	(39,'登陆页面','page.login','<div class=\"ui-register-login\">\r\n    <div class=\"form\">\r\n        <?php $form = \\yii\\widgets\\ActiveForm::begin() ?>\r\n        <h1 class=\"title\">用户登录</h1>\r\n\r\n        <div class=\"form-item\">\r\n            <div class=\"input\">\r\n                <i class=\"icon\"><img src=\"/images/login-phone.png\" alt=\"\"></i>\r\n                <?= \\yii\\helpers\\Html::activeTextInput($model, \"phone\", [\r\n                    \'autocomplete\' => \'off\',\r\n                    \'type\'         => \'tel\',\r\n                    \'pattern\'      => \'\\d*\',\r\n                    \'id\'           => \'phone\',\r\n                    \'placeholder\'  => \'请输入手机号\',\r\n                ]) ?>\r\n            </div>\r\n        </div>\r\n\r\n        <div class=\"form-item\">\r\n            <?php if ($mode == \"password\") { ?>\r\n                <div class=\"input\">\r\n                    <i class=\"icon\"><img src=\"/images/login-password.png\" alt=\"\"></i>\r\n                    <?= \\yii\\helpers\\Html::activeTextInput($model, \"password\", [\r\n                        \'placeholder\' => \'请输入密码\',\r\n                    ]) ?>\r\n                </div>\r\n            <?php } else { ?>\r\n                <div class=\"input ui-flex-input\">\r\n                    <i class=\"icon\"><img src=\"/images/login-password.png\" alt=\"\"></i>\r\n                    <?= \\yii\\helpers\\Html::activeTextInput($model, \"code\", [\r\n                        \'autocomplete\' => \'off\',\r\n                        \'type\'         => \'tel\',\r\n                        \'pattern\'      => \'\\d{6}\',\r\n                        \'id\'           => \'code\',\r\n                        \'placeholder\'  => \'请输入难验证码\',\r\n                    ]) ?>\r\n                    <button class=\"get-code ui-btn-main\" id=\"action-btn-get-code\">获取验证码</button>\r\n                </div>\r\n            <?php } ?>\r\n        </div>\r\n\r\n        <div class=\"form-submit\">\r\n            <div class=\"input\">\r\n                <?= \\yii\\helpers\\Html::submitButton(\"登录\", [\r\n                    \'class\' => \'ui-btn-lg ui-btn-submit\',\r\n                ]) ?>\r\n            </div>\r\n\r\n            <ul class=\"ui-tiled  mt-20\">\r\n                <li>\r\n                    <div class=\"ui-full-width ui-align-left\">\r\n                        <a href=\"/register\" class=\"ui-txt-white\">还没有账号？快速注册</a>\r\n                    </div>\r\n                </li>\r\n                <li>\r\n                    <div class=\"ui-full-width ui-align-right\">\r\n                        <?php\r\n                        if ($mode == \"password\") {\r\n                            echo \\yii\\helpers\\Html::a(\"短信验证码登录\", [\'/login\', \'mode\' => \'code\'], [\r\n                                \'class\' => \'ui-txt-white\',\r\n                                \'id\'    => \'action-login-by-code\',\r\n                            ]);\r\n                        } else {\r\n                            echo \\yii\\helpers\\Html::a(\"使用密码登陆\", [\'/login\', \'mode\' => \'password\'], [\r\n                                \'class\' => \'ui-txt-white\',\r\n                                \'id\'    => \'action-login-by-code\',\r\n                            ]);\r\n                        }\r\n                        ?>\r\n                    </div>\r\n                </li>\r\n            </ul>\r\n        </div>\r\n        <?php \\yii\\widgets\\ActiveForm::end() ?>\r\n    </div>\r\n</div>\r\n\r\n<script>\r\n    function delayCodeSend() {\r\n        $(\"#action-btn-get-code\").attr(\"disabled\", true);\r\n\r\n        var timeDelay = 60;\r\n        var _timer = setInterval(function () {\r\n            $(\"#action-btn-get-code\").html(timeDelay-- + \" 秒后重新获取\");\r\n        }, 1000);\r\n\r\n        setTimeout(function () {\r\n            $(\"#action-btn-get-code\").removeAttr(\"disabled\");\r\n            $(\"#action-btn-get-code\").html(\"获取验证码\");\r\n            clearInterval(_timer);\r\n        }, timeDelay * 1000);\r\n    }\r\n\r\n    $(function () {\r\n        $(\"body\").on(\"click\", \"#action-btn-get-code\", function (e) {\r\n            e.preventDefault();\r\n\r\n            var _phone = $(\"#phone\").val();\r\n            $.get(\"/sms/send\", {phone: _phone, action: \"login\"}, function (data) {\r\n                if (data.code != 0) {\r\n                    msgTip(data.data);\r\n                    return false;\r\n                }\r\n\r\n                msgTip(\"验证码已发送\");\r\n                delayCodeSend();\r\n            });\r\n        });\r\n    })\r\n</script>',0),
	(40,'用户注册','page.register','<div class=\"ui-register-login\">\r\n    <div class=\"ui-backdrop-filter\"></div>\r\n\r\n    <div class=\"form\">\r\n        <?php $form = \\yii\\widgets\\ActiveForm::begin() ?>\r\n        <h1 class=\"title\">用户注册</h1>\r\n\r\n        <div class=\"form-item\">\r\n            <div class=\"input\">\r\n                <i class=\"icon\"><img src=\"/images/login-phone.png\" alt=\"\"></i>\r\n                <?= \\yii\\helpers\\Html::activeTextInput($model, \"phone\", [\r\n                    \'autocomplete\' => \'off\',\r\n                    \'type\'         => \'tel\',\r\n                    \'pattern\'      => \'\\d*\',\r\n                    \'id\'           => \'phone\',\r\n                ]) ?>\r\n            </div>\r\n        </div>\r\n\r\n        <div class=\"form-item\">\r\n            <div class=\"input ui-flex-input\">\r\n                <i class=\"icon\"><img src=\"/images/login-password.png\" alt=\"\"></i>\r\n                <?= \\yii\\helpers\\Html::activeTextInput($model, \"code\", [\r\n                    \'autocomplete\' => \'off\',\r\n                    \'type\'         => \'tel\',\r\n                    \'pattern\'      => \'\\d{6}\',\r\n                    \'id\'           => \'code\',\r\n                ]) ?>\r\n                <button class=\"get-code ui-btn-main\" id=\"action-btn-get-code\">获取验证码</button>\r\n            </div>\r\n        </div>\r\n\r\n        <div class=\"form-item\">\r\n            <div class=\"input\">\r\n                <i class=\"icon\"><img src=\"/images/login-password.png\" alt=\"\"></i>\r\n                <?= \\yii\\helpers\\Html::activeTextInput($model, \"password\") ?>\r\n            </div>\r\n        </div>\r\n\r\n        <div class=\"form-submit\">\r\n            <div class=\"input\">\r\n                <?= \\yii\\helpers\\Html::submitButton(\"注册\", [\r\n                    \'class\' => \'ui-btn-lg ui-btn-submit\',\r\n                ]) ?>\r\n            </div>\r\n            <div class=\"ui-align-right mt-20\">\r\n                <a href=\"/login\" class=\"ui-txt-white\">已有账号？前往登录页面</a>\r\n            </div>\r\n        </div>\r\n        <?php \\yii\\widgets\\ActiveForm::end() ?>\r\n    </div>\r\n</div>\r\n\r\n<script>\r\n    function delayCodeSend() {\r\n        $(\"#action-btn-get-code\").attr(\"disabled\", true);\r\n\r\n        var timeDelay = 60;\r\n        var _timer = setInterval(function () {\r\n            $(\"#action-btn-get-code\").html(timeDelay-- + \" 秒后重新获取\");\r\n        }, 1000);\r\n\r\n        setTimeout(function () {\r\n            $(\"#action-btn-get-code\").removeAttr(\"disabled\");\r\n            $(\"#action-btn-get-code\").html(\"获取验证码\");\r\n            clearInterval(_timer);\r\n        }, timeDelay * 1000);\r\n    }\r\n\r\n    $(function () {\r\n        $(\"body\").on(\"click\", \"#action-btn-get-code\", function (e) {\r\n            e.preventDefault();\r\n\r\n            var _phone = $(\"#phone\").val();\r\n            $.get(\"/sms/send\", {phone: _phone, action: \"register\"}, function (data) {\r\n                if (data.code != 0) {\r\n                    msgTip(data.data);\r\n                    return false;\r\n                }\r\n\r\n                msgTip(\"验证码已发送\");\r\n                delayCodeSend();\r\n            });\r\n        });\r\n    })\r\n\r\n</script>',0),
	(41,'就诊评价表单','page.appointment.feedback-form','<?php $form = \\yii\\widgets\\ActiveForm::begin(); ?>\r\n<div class=\"ui-panel p-15 ui-appointment-feedback-form\">\r\n    <div class=\"mt-20 mb-20\">\r\n        <label class=\"ui-block\">服务评分</label>\r\n        <div class=\"mark-star-container ui-block-textarea-wrapper\">\r\n            <i class=\"ui-icon-star\" data-id=\"1\"></i>\r\n            <i class=\"ui-icon-star\" data-id=\"2\"></i>\r\n            <i class=\"ui-icon-star\" data-id=\"3\"></i>\r\n            <i class=\"ui-icon-star\" data-id=\"4\"></i>\r\n            <i class=\"ui-icon-star\" data-id=\"5\"></i>\r\n        </div>\r\n        <?= \\yii\\helpers\\Html::activeHiddenInput($model, \"mark\", [\'id\' => \'feedback-mark\']) ?>\r\n    </div>\r\n    <div class=\"mt-20 mb-20\">\r\n        <label class=\"ui-block\">评价信息</label>\r\n        <div class=\"ui-block-textarea-wrapper\">\r\n            <?= \\yii\\helpers\\Html::activeTextarea($model, \"content\", [\r\n                \'class\'       => \'ui-block-textarea\',\r\n                \'rows\'        => 5,\r\n                \'placeholder\' => \"请对您本次会诊的看法进行描述\",\r\n            ]) ?>\r\n        </div>\r\n    </div>\r\n</div>\r\n\r\n<div class=\"ui-btn-wrap mt-20\">\r\n    <input type=\"submit\" value=\"确定\" class=\"ui-btn-lg ui-btn-primary ui-btn-main\"/>\r\n</div>\r\n<?php \\yii\\widgets\\ActiveForm::end() ?>\r\n\r\n<script>\r\n    $(\"body\").on(\"click\", \".ui-icon-star\", function (e) {\r\n        e.preventDefault();\r\n\r\n        var lightID = $(this).attr(\"data-id\");\r\n        $(\".mark-star-container i\").removeClass(\"light\");\r\n\r\n        $(\".mark-star-container i\").each(function (index, item) {\r\n            if ($(item).attr(\"data-id\") <= lightID) {\r\n                $(item).addClass(\"light\");\r\n            }\r\n        })\r\n\r\n        $(\"#feedback-mark\").val(lightID);\r\n    });\r\n</script>',0),
	(42,'我的评价列表','page.appointment.feedback-list','<div class=\"ui-appointment-feedback-list mt-20\">\r\n    <?php foreach ($models as $model): ?>\r\n        <div class=\"ui-panel mb-20\">\r\n            <div class=\"ui-panel-body  ui-border-b\">\r\n                <div class=\"patient-info\">\r\n                    <div class=\"ui-align-left\">\r\n                        <?= $model->appointment->patientInfo->name ?>\r\n                    </div>\r\n                    <div class=\"ui-align-right\">\r\n                        <?= \"就诊日期：\" . date(\"Y年m月d日\", $model->appointment->time_begin); ?>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n\r\n            <div class=\"ui-panel-body\">\r\n                <div class=\"doctor-info mb-20\">\r\n                    <div class=\"head-info\">\r\n                        <?= \\yii\\helpers\\Html::img($model->doctor->head_image) ?>\r\n                    </div>\r\n                    <div class=\"name-info\">\r\n                        <p class=\"name\">\r\n                            <?= $model->doctor->name ?>&nbsp;\r\n                        </p>\r\n                        <p class=\"ui-txt-info\">\r\n                            <?= $model->doctor->levelModel->level_name ?>\r\n                        </p>\r\n                    </div>\r\n                </div>\r\n\r\n                <div class=\"feedback-mark\">\r\n                    <?php\r\n                    for ($i = 0; $i < $model->mark; $i++) {\r\n                        echo \\yii\\helpers\\Html::tag(\"i\", \"\", [\r\n                            \'class\' => \'ui-icon-star light\',\r\n                        ]);\r\n                    }\r\n                    for ($i = 0; $i < (5 - $model->mark); $i++) {\r\n                        echo \\yii\\helpers\\Html::tag(\"i\", \"\", [\r\n                            \'class\' => \'ui-icon-star\',\r\n                        ]);\r\n                    }\r\n                    ?>\r\n                </div>\r\n                <div class=\"feedback-content pt-15 pb-15\">\r\n                    <?= $model->content ?>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    <?php endforeach; ?>\r\n</div>\r\n',0),
	(43,'我的预约','page.appointment.mine','<div class=\"ui-appointment-list mt-20\">\r\n    <?php foreach ($models as $model): ?>\r\n        <div class=\"ui-panel mb-20\">\r\n            <div class=\"ui-panel-heading ui-border-b flex-show\">\r\n                <div class=\"order-id\">\r\n                    <?= $model->getOrder()->order_id ?>\r\n                </div>\r\n                <div class=\"status-show\">\r\n                    <?php\r\n                    $statusOK      = $model->status == \\common\\models\\DoctorAppointment::STATUS_COMPLETE;\r\n                    $feedbackModel = $model->feedback;\r\n                    if ($statusOK && !$feedbackModel) {\r\n                        echo \\yii\\helpers\\Html::a(\'立即评价\', [\"/appointment/feedback\", \"id\" => $model->id], [\'class\' => \'ui-btn ui-btn-main\']);\r\n                    }\r\n                    \r\n                    if ($feedbackModel) {\r\n                        echo \"已评价\";\r\n                    }\r\n                    ?>\r\n                    \r\n                    <?php\r\n                    $orderModel = $model->getOrderModel();\r\n                    if ($orderModel && $orderModel->status == \\common\\models\\Order::STATUS_PENDING_PAY) {\r\n                        $payLink = [\"/pay/index\", \'id\' => $orderModel->order_id];\r\n                        echo \\yii\\helpers\\Html::a(\"立即支付\", $payLink);\r\n                    }\r\n                    \r\n                    if ($orderModel && in_array($orderModel->status , [\\common\\models\\Order::STATUS_PAY_REFUND, \\common\\models\\Order::STATUS_PAY_CLOSED])) {\r\n                        echo \'已取消\';\r\n                    }\r\n                    ?>\r\n                </div>\r\n            </div>\r\n\r\n            <a class=\"ui-panel-body\" href=\"/appointment/detail?id=<?=$model->id?>\">\r\n                <div class=\"doctor-info\">\r\n                    <div class=\"head\">\r\n                        <?= \\yii\\helpers\\Html::img($model->doctor->head_image) ?>\r\n                    </div>\r\n                    <div class=\"info\">\r\n                        <div class=\"name-info\">\r\n                            <div class=\"name\">\r\n                                <?= $model->doctor->name ?>\r\n                                &nbsp;<?= $model->doctor->levelModel->level_name ?>\r\n                            </div>\r\n                            <div class=\"price-info\">\r\n                                诊费：<span class=\"price-show\">&yen;<?= $model->getPrice() ?></span>\r\n                            </div>\r\n                        </div>\r\n                        <p class=\"ui-txt-info\">\r\n                            就诊日期：\r\n                            <?= date(\"Y年m月d日\", $model->time_begin); ?>\r\n                            <?= date(\"H:i\", $model->time_begin); ?>~<?= date(\"H:i\", $model->time_end); ?>\r\n                        </p>\r\n                        <p class=\"ui-txt-info\">\r\n                            就诊人：<?= $model->patientInfo->name ?>\r\n                        </p>\r\n                    </div>\r\n                </div>\r\n            </a>\r\n        </div>\r\n    <?php endforeach; ?>\r\n</div>',0),
	(44,'医生预约:医生列表','page.appointment.list','{% index.search-box %}\r\n{% element.doctor_filter %}\r\n\r\n<div class=\"row ui-page-appointment\">\r\n    <ul class=\"ui-list ui-border-tb\">\r\n        <?php foreach ($items as $item): ?>\r\n            <?php\r\n            $url = [\'/doctor\', \'id\' => $item->id];\r\n            ?>\r\n            <li class=\"doctor-list\">\r\n                <a href=\"<?= \\yii\\helpers\\Url::to($url) ?>\" class=\"ui-avatar\">\r\n                    <?= \\yii\\helpers\\Html::img($item->head_image) ?>\r\n                </a>\r\n                <div class=\"ui-list-info ui-border-t\">\r\n                    <div class=\"ui-row-flex\">\r\n                        <div class=\"ui-col doctor-info\">\r\n                            <h4 class=\"ui-nowrap mb-5\">\r\n                                <?= \\yii\\helpers\\Html::a($item->name, $url, [\'class\' => \'doctor-name\']) ?>\r\n                                <span class=\"subtitle\"><?= $item->levelModel->level_name ?></span>\r\n                            </h4>\r\n                            <div class=\"ui-label-list ui-no-margin mb-5\">\r\n                                <span class=\"ui-label-head\">擅长:</span>\r\n\r\n                                <?php foreach ($item->departments as $department): ?>\r\n                                    <label class=\"ui-label-s\"><?= $department->department->name ?></label>\r\n                                <?php endforeach; ?>\r\n                            </div>\r\n                            <p class=\"ui-desc\">\r\n                                <span>\r\n                                    评分：\r\n                                    <span class=\"count\"><?=\\common\\models\\PatientFeedback::getDoctorMark($item->id)?></span>\r\n                                    |\r\n                                </span>\r\n\r\n                                <span>\r\n                                    评价：\r\n                                    <span class=\"count\"><?=\\common\\models\\PatientFeedback::count([\"doctor_id\"=>$item->id])?></span>\r\n                                    |\r\n                                </span>\r\n                                <span>\r\n                                    接诊：\r\n                                    <span class=\"count\"><?=\\common\\models\\DoctorAppointment::count([\"doctor_id\"=>$item->id,\"status\"=>\"0\"])?></span>\r\n                                </span>\r\n                            </p>\r\n                        </div>\r\n                        <div class=\"ui-flex ui-flex-ver ui-flex-pack-center ui-flex-align-center ui-btn-group-wrapper\">\r\n                            <div class=\"ui-txt-center mb-20 price\">&yen;<?=$item->doctorServiceTime->price?></div>\r\n                            <a href=\"<?= \\yii\\helpers\\Url::to($url) ?>\" class=\"ui-btn-s\">立即预约</a>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </li>\r\n        <?php endforeach; ?>\r\n    </ul>\r\n</div>\r\n',0),
	(45,'就诊人列表-展示模式','page.patient-list-mode-show','<div class=\"ui-my-patient-list\">\r\n    {% element.patient-list.alert %}\r\n\r\n    <div class=\"list-wrapper mb-20\">\r\n        <?php foreach ($models as $model): ?>\r\n            <div class=\"ui-panel mb-20 ui-user-info\">\r\n                <div class=\"ui-panel-heading\">\r\n                    <div>\r\n                        <?=$model->name?>&nbsp;\r\n                        <?=$model->getSexDesc()?>&nbsp;\r\n                        <?=$model->getAge()?>\r\n                    </div>\r\n                    <div><?=$model->phone?></div>\r\n                </div>\r\n                <div class=\"ui-panel-body\">\r\n                    <?php if($model->default){?>\r\n                        <button class=\"ui-btn-s ui-btn-primary  action-set-default\" data-id=\"<?=$model->id?>\">默认联系人</button>\r\n                    <?php }else{?>\r\n                        <button class=\"ui-btn-s action-set-default\" data-id=\"<?=$model->id?>\">默认联系人</button>\r\n                    <?php }?>\r\n                    <button class=\"action-remove ui-btn-s ui-btn-danger\" data-id=\"<?=$model->id?>\">删除</button>\r\n                </div>\r\n            </div>\r\n        <?php endforeach; ?>\r\n    </div>\r\n\r\n    <div class=\"ui-btn-wrapper\">\r\n        <?= \\yii\\helpers\\Html::a(\"添加新就诊人\", [\'/patient/create\',\'mode\'=>\'show\'], [\r\n            \'class\' => \'ui-btn-lg ui-btn-add-new-patient\'\r\n        ]) ?>\r\n    </div>\r\n</div>\r\n\r\n<script>\r\n    $(function(){\r\n        // set default user\r\n        $(\"body\").on(\"click\",\".action-set-default\",function(){\r\n            $.get(\"/patient/set-default\",{id:$(this).attr(\"data-id\")},function(data){\r\n                $(\".ui-btn-s\").removeClass(\"ui-btn-primary\")\r\n                $(this).addClass(\"ui-btn-primary\")\r\n            }.bind(this));\r\n        })\r\n        \r\n        //  remove user\r\n        $(\"body\").on(\"click\",\".action-remove\",function(){\r\n            if (!confirm(\"确认删除此用户？\")){\r\n                return false;\r\n            }\r\n            \r\n            $.get(\"/patient/delete\",{id:$(this).attr(\"data-id\")},function(data){\r\n                $(this).closest(\".ui-panel\").remove();\r\n                msgTip(\"删除成功！\")\r\n            });\r\n        });\r\n        \r\n        $(\"body\").on(\"tap\",\"i.ui-icon-checked-s\",function(){\r\n                        \r\n        })\r\n    })\r\n    \r\n</script>',1001),
	(46,'医生就诊时间选择','element.doctor-service-time-range','<ul>\r\n    <?php if (empty($timeRange)) {\r\n        echo \\yii\\helpers\\Html::tag(\"span\", \"暂无排班\");\r\n    } ?>\r\n\r\n    <?php foreach ($timeRange as $timeRangeItem): ?>\r\n        <li>\r\n            <?php\r\n            $title = sprintf(\"<p class=\'time-range\'>%s</p><p>剩余%d号源</p>\",$timeRangeItem[\'time\'] ,  $timeRangeItem[\'count\']);\r\n            $url   = [\r\n                \"/doctor/order\",\r\n                \'date\' => $date,\r\n                \'time\' => $timeRangeItem[\'time\'],\r\n                \'id\'   => $doctor,\r\n            ];\r\n            if ($timeRangeItem[\'count\'] == 0){\r\n                echo \\yii\\helpers\\Html::a($title, \"#\",[\'class\'=>\'disable\']);\r\n            }else{\r\n                echo \\yii\\helpers\\Html::a($title, $url, [\'class\'=>\"ui-arrowlink\"]);\r\n            }\r\n            ?>\r\n        </li>\r\n    <?php endforeach; ?>\r\n</ul>',2008),
	(47,'会员卡列表','page.card-list','<div class=\"ui-alert-tips\">\r\n    <i><img src=\"/images/icon-alert.png\"/></i>\r\n    <span><a href=\"/card/rules\">会员卡使用须知</a></span>\r\n</div>\r\n\r\n<?php\r\n$memberOwnCard = \\common\\models\\MemberOwnCard::getUserEnableCard(\\common\\utils\\UserSession::getId());\r\n$memberOwnCardOrderID = 0;\r\nif ($memberOwnCard){\r\n     $memberOwnCardOrderID = $memberOwnCard->card->order;\r\n}\r\nforeach ($models as $model):\r\n    if (\\common\\utils\\Request::input(\"mode\") == \"upgrade\"){\r\n        if ($model->order > $memberOwnCardOrderID){break;}\r\n    }\r\n    ?>\r\n    <a href=\"<?= \\yii\\helpers\\Url::to([\"/card/detail\", \"id\" => $model->id]) ?>\" class=\"card-cover\">\r\n        <img src=\"<?=$model->getOption(\"image\")?>\" alt=\"\">\r\n    </a>\r\n<?php endforeach; ?>\r\n',0),
	(48,'在线问诊确认支付页面','page.ask-checkout','<div class=\"ui-container ui-patient-ask-checkout\">\r\n    <div class=\"ui-panel\">\r\n        <div class=\"ui-panel-heading\">\r\n            <div class=\"doctor-head-img\">\r\n                <?= \\yii\\helpers\\Html::img($model->doctor->head_image) ?>\r\n            </div>\r\n            <div class=\"doctor-info\">\r\n                <div class=\"doctor-name\">\r\n                    <?= $model->doctor->name ?>&nbsp;<?= $model->doctor->levelModel->level_name ?>\r\n                </div>\r\n                <div class=\"appartment ui-txt-info\">\r\n                    科室：<?= $model->doctor->departmentString() ?>\r\n                </div>\r\n                <div class=\"ui-txt-info\">\r\n                    问诊量：<?= \\common\\models\\PatientAsk::count([\'patient_id\' => $model->doctor_id]) ?>\r\n                </div>\r\n            </div>\r\n        </div>\r\n\r\n        <div class=\"ui-panel-body ui-border-b\">\r\n            <strong>服务：</strong>在线咨询\r\n        </div>\r\n\r\n        <div class=\"ui-panel-body ui-price-type-wrapper ui-border-b\">\r\n            <div>\r\n                <strong>服务费</strong>\r\n            </div>\r\n            <div class=\"price\">&yen; <?= $model->doctor->ask_price ?></div>\r\n        </div>\r\n\r\n        <div class=\"ui-panel-body ui-border-b\">\r\n            <div><strong>咨询说明：</strong></div>\r\n            <ul class=\"ui-txt-info\">\r\n                <li>1. 医生本人回答</li>\r\n                <li>2. 24小时未回复自动退款</li>\r\n                <li>3. 医生回复后48小时不限次提问</li>\r\n            </ul>\r\n        </div>\r\n\r\n        <div class=\"ui-panel-body ui-border-b\">\r\n            <div><strong>在线咨询时间：</strong></div>\r\n            <div class=\"ui-txt-info\">\r\n                平时门诊较忙，空闲时会及时回复\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n\r\n<footer class=\"ui-footer ui-footer-stable ui-patient-ask-checkout-footer\">\r\n    <div class=\"price\">\r\n        应付金额: <span class=\"price-show\">&yen;<?= $model->doctor->ask_price ?></span>\r\n    </div>\r\n    <a class=\"pay-btn\" href=\"<?= \\yii\\helpers\\Url::to([\'pay/index\', \'id\' => $orderID]) ?>\">去支付</a>\r\n</footer>\r\n',0),
	(49,'患者评价列表','page.doctor-feedback','<?php foreach ($models as $feedbackModel): ?>\r\n    <section class=\"ui-panel mb-20\">\r\n        <div class=\"ui-panel-body ui-patient-feedback\">\r\n            <div class=\"ui-patient-info ui-flex ui-justify-flex ui-flex-align-center\">\r\n                <div class=\"ui-head-info\">\r\n                    <div class=\" ui-flex ui-flex-align-center\">\r\n                        <div class=\"ui-avatar-s\">\r\n                            <img src=\"<?= $feedbackModel->appointment->user->head_image ?>\" alt=\"\">\r\n                        </div>\r\n                        <div class=\"ui-patient-name\">\r\n                            <?= $feedbackModel->maskPatientName() ?>\r\n                        </div>\r\n                        <div class=\"ui-patient-status\">已就诊</div>\r\n                    </div>\r\n                </div>\r\n\r\n                <div class=\"ui-patient-datetime ui-txt-info\"><?= date(\"Y-m-d\", $feedbackModel->created_at) ?></div>\r\n            </div>\r\n            <div class=\"ui-patient-evaluate  ui-flex ui-flex-align-center\">\r\n                <?php for ($i = 0; $i < $feedbackModel->mark; $i++): ?>\r\n                    <i class=\"ui-icon-star\"></i>\r\n                <?php endfor; ?>\r\n            </div>\r\n\r\n            <div class=\"ui-feedback ui-txt-info ui-txt-size-14\">\r\n                <?= $feedbackModel->content; ?>\r\n            </div>\r\n        </div>\r\n    </section>\r\n<?php endforeach; ?>',0),
	(50,'用户咨询回复内容','page.ask-reply-content','<div class=\"ui-panel\">\r\n    <div class=\"ui-panel-body\">\r\n        <h3 style=\"padding:0;\">咨询内容：</h3>\r\n        <?= \\yii\\helpers\\Html::encode($model->description) ?>\r\n    </div>\r\n\r\n    <?php if (!empty($model->images)): ?>\r\n        <div class=\"ui-panel-body ui-border-t\">\r\n            <ul class=\"image-list\">\r\n                <?php foreach ($model->getImageList() as $imageUrl): ?>\r\n                    <li>\r\n                        <?= \\yii\\helpers\\Html::img($imageUrl) ?>\r\n                    </li>\r\n                <?php endforeach; ?>\r\n            </ul>\r\n        </div>\r\n    <?php endif; ?>\r\n\r\n    <div class=\"ui-panel-body ui-border-t\">\r\n        <h3 style=\"padding:0;\">医生回复：</h3>\r\n        <?= \\yii\\helpers\\Html::encode($model->reply) ?>\r\n    </div>\r\n\r\n    <div class=\"ui-panel-body ui-border-t\">\r\n        <?php\r\n        $url = \\common\\models\\WebsiteConfig::getByKey(\"global.chat-link\");\r\n        echo \\yii\\helpers\\Html::a(\"继续咨询\", $url, [\r\n            \'class\' => \'ui-btn-lg ui-btn-primary\',\r\n        ]) ?>\r\n    </div>\r\n</div>',0),
	(51,'订单付款页面','page.order-checkout','<?php\r\n\r\n/** @var $model \\common\\models\\Order */\r\n/** @var $this \\common\\extend\\View */\r\n\r\n$userCoin = \\common\\utils\\UserSession::getCoin();\r\n$coinRate = \\common\\models\\WebsiteConfig::getValueByKey(\"global.coin-rate\");\r\n$coinMoney = $userCoin * $coinRate;\r\n\r\n$userCard = \\common\\models\\MemberOwnCard::getUserEnableCard(\\common\\utils\\UserSession::getId());\r\n$discountRate = 0;\r\nif ($userCard) {\r\n    $discountRate = 1 - $userCard->discount / 100;\r\n}\r\n\r\n?>\r\n\r\n<footer class=\"ui-footer ui-footer-stable ui-pay-order-footer\">\r\n    <div class=\"price\">总计: <span class=\"price-show\"><?= $model->getPriceYuan() ?></span></div>\r\n    <div class=\"pay-btn disabled\">支付</div>\r\n</footer>\r\n\r\n<section class=\"ui-container pb-10 ui-pay-order\">\r\n    <?php if ($enableCode): ?>\r\n        <div class=\"ui-form ui-border-t mt-20\">\r\n            <div class=\"ui-form-item ui-form-item-show ui-border-b\">\r\n                <label for=\"#\">优惠券</label>\r\n                <input type=\"text\" value=\"\" id=\"code\" placeholder=\"请输入优惠券码\">\r\n            </div>\r\n        </div>\r\n        <p id=\"code-info-show\" class=\"ui-txt-info pl-15 ui-hide\">优惠券抵扣 <span></span> 元</p>\r\n    <?php endif; ?>\r\n\r\n    <?php if ($enableCoin): ?>\r\n        <div class=\"ui-form ui-border-t mt-20\">\r\n            <div class=\"ui-form-item ui-form-item-switch ui-border-b\">\r\n                <p>使用 <?= $userCoin ?> 积分抵换 <?= $coinMoney ?> 元</p>\r\n                <label class=\"ui-switch\">\r\n                    <input type=\"checkbox\" id=\"coin\">\r\n                </label>\r\n            </div>\r\n        </div>\r\n    <?php endif; ?>\r\n\r\n    <ul class=\"ui-list ui-list-link ui-border-tb mt-20 pay-method-list\">\r\n        <?php\r\n        $payChannel = \\common\\models\\LinkGroup::getLinkItems(\"pay-channel\");\r\n        foreach ($payChannel as $channel):\r\n            if ($channel->slug == \"card\") {\r\n                if (!$enableCard || !$userCard) {\r\n                    continue;\r\n                }\r\n            }\r\n            ?>\r\n            <li data-name=\"<?= $channel->slug ?>\">\r\n                <div class=\"ui-avatar\">\r\n                    <span style=\"background-image:url(<?=$channel->getOption(\"icon\")?>)\"></span>\r\n                </div>\r\n                <div class=\"ui-list-info ui-border-t\">\r\n                    <h4 class=\"ui-nowrap\">\r\n                        <?= $channel->name ?>\r\n                        <?php\r\n                        if ($channel->slug == \"card\") {\r\n                            echo \\yii\\helpers\\Html::tag(\"span\", \"余额：\" . $userCard->remain_money, [\r\n                                \'class\' => \'ui-txt-info\',\r\n                            ]);\r\n                        }\r\n                        ?>\r\n                    </h4>\r\n                </div>\r\n            </li>\r\n        <?php endforeach; ?>\r\n    </ul>\r\n</section>\r\n\r\n<?php\r\n$form = \\yii\\widgets\\ActiveForm::begin([\'options\' => [\'id\' => \'form\']]);\r\necho \\yii\\helpers\\Html::hiddenInput(\"id\", $model->order_id);\r\necho \\yii\\helpers\\Html::hiddenInput(\"data[code]\", \"\", [\'id\' => \"form-code\"]);\r\necho \\yii\\helpers\\Html::hiddenInput(\"data[coin]\", 0, [\'id\' => \"form-coin\"]);\r\necho \\yii\\helpers\\Html::hiddenInput(\"data[channel]\", \"\", [\'id\' => \"form-channel\"]);\r\n\\yii\\widgets\\ActiveForm::end();\r\n?>\r\n\r\n<script>\r\n    var orderPrice =<?=$model->getPriceYuan()?>;\r\n    var coinMoney = <?=$coinMoney?>;\r\n    var cardMoney = <?=floatval($userCard->remain_money) ?>;\r\n    var discountRate = <?=$discountRate?>;\r\n    var minusPrice = {\r\n        code: 0,\r\n        coin: 0,\r\n        discount: 0\r\n    };\r\n\r\n    function setPrice() {\r\n        var payPrice = orderPrice - minusPrice.code - minusPrice.coin - minusPrice.discount;\r\n        if (payPrice < 0) {\r\n            payPrice = 0;\r\n        }\r\n        $(\".price-show\").text(payPrice);\r\n    }\r\n\r\n    function goSuccessPage() {\r\n        location.href = \"<?=\\yii\\helpers\\Url::to([\'pay/success\', \'id\' => $model->order_id])?>\";\r\n    }\r\n\r\n    function togglePayBtn() {\r\n        if ($(\".pay-btn\").hasClass(\"disabled\")) {\r\n            $(\".pay-btn\").removeClass(\"disabled\");\r\n            return;\r\n        }\r\n\r\n        $(\".pay-btn\").addClass(\"disabled\");\r\n    }\r\n\r\n    $(function () {\r\n        $(\"body\").on(\"change\", \"#coin\", function () {\r\n            var checked = $(this).is(\":checked\");\r\n            if (checked) {\r\n                minusPrice.coin = coinMoney;\r\n                setPrice();\r\n\r\n                $(\"#form-coin\").val(1);\r\n                return;\r\n            }\r\n\r\n            minusPrice.coin = 0;\r\n            setPrice();\r\n\r\n            $(\"#form-coin\").val(0);\r\n        });\r\n\r\n        $(\"body\").on(\"blur\", \"#code\", function () {\r\n            if ($(this).val().length == 0) {\r\n                return;\r\n            }\r\n            var _code = $(this).val();\r\n            $.get(\"/pay/code-info\", {code: _code}, function (data) {\r\n                if (data.code != 0) {\r\n                    if (!$(\"#code-info-show\").hasClass(\"ui-hide\")) {\r\n                        $(\"#code-info-show\").addClass(\"ui-hide\");\r\n                    }\r\n\r\n                    $(\"#code\").val(\"\");\r\n                    $(\"#form-code\").val(\"\");\r\n                    minusPrice.code = 0;\r\n                    setPrice();\r\n                    msgTip(data.data);\r\n                    return;\r\n                }\r\n\r\n                $(\"#code-info-show span\").text(data.data);\r\n                $(\"#code-info-show\").removeClass(\"ui-hide\");\r\n                $(\"#form-code\").val(_code);\r\n\r\n                minusPrice.code = data.data;\r\n                setPrice();\r\n            })\r\n        });\r\n\r\n        $(\"body\").on(\"tap\", \".pay-method-list li\", function () {\r\n            $(this).siblings().removeClass(\"select\");\r\n            $(this).addClass(\"select\");\r\n\r\n            var _name = $(this).attr(\"data-name\");\r\n            $(\"#form-channel\").val(_name);\r\n            console.log(\"paychannel: \", _name);\r\n\r\n            if (_name == \"card\") {\r\n                minusPrice.discount = orderPrice * discountRate;\r\n                console.log(minusPrice.discount)\r\n            } else {\r\n                minusPrice.discount = 0;\r\n            }\r\n\r\n            setPrice();\r\n        });\r\n\r\n        $(\"body\").on(\"tap\", \".pay-btn\", function () {\r\n            if ($(this).hasClass(\"disabled\")) {\r\n                return;\r\n            }\r\n\r\n            if ($(\"#form-channel\").val().length == 0) {\r\n                msgAlert(\"请选择支付方式\");\r\n                return;\r\n            }\r\n\r\n            var payChannel = $(\"#form-channel\").val();\r\n\r\n            togglePayBtn();\r\n\r\n            var formParams = $(\"#form\").serialize();\r\n            //card pay\r\n            if (payChannel == \"card\") {\r\n                var _currentPrice = orderPrice - minusPrice.code - minusPrice.coin - minusPrice.discount;\r\n                if (_currentPrice > cardMoney) {\r\n                    msgAlert(\"会员卡余额不足够，请选择其它支付方式，或充值后支付!\");\r\n                    togglePayBtn();\r\n                    return false;\r\n                }\r\n\r\n                $.get(\"/pay/checkout\", formParams, function (data) {\r\n                    if (data.code != 0) {\r\n                        msgAlert(data.data);\r\n                        return false;\r\n                    }\r\n                    goSuccessPage();\r\n                });\r\n                return;\r\n            }\r\n\r\n            if (payChannel == \"wechat-pay\") {\r\n                $.get(\"/pay/checkout\", formParams, function (data) {\r\n                    if (data.code != 0) {\r\n                        msgTip(\"支付信息拉取失败,请重新支付！\");\r\n                        togglePayBtn();\r\n                        return false;\r\n                    }\r\n\r\n                    WeixinJSBridge.invoke(\r\n                        \'getBrandWCPayRequest\',\r\n                        data.data,\r\n                        function (res) {\r\n                            if (res.err_msg == \"get_brand_wcpay_request:ok\") {\r\n                                goSuccessPage();\r\n                            } else {\r\n                                msgTip(\"支付失败， 请重新支付！\");\r\n                                togglePayBtn();\r\n                            }\r\n                        }\r\n                    );\r\n\r\n                });\r\n                return;\r\n            }\r\n\r\n            if (payChannel == \"alipay\") {\r\n                msgTip(\"不支持此通道\");\r\n                togglePayBtn();\r\n                return;\r\n            }\r\n\r\n        });\r\n    });\r\n\r\n    // wechat pay\r\n    function onBridgeReady() {\r\n        togglePayBtn();\r\n    }\r\n\r\n    if (typeof WeixinJSBridge == \"undefined\") {\r\n        if (document.addEventListener) {\r\n            document.addEventListener(\'WeixinJSBridgeReady\', onBridgeReady, false);\r\n        } else if (document.attachEvent) {\r\n            document.attachEvent(\'WeixinJSBridgeReady\', onBridgeReady);\r\n            document.attachEvent(\'onWeixinJSBridgeReady\', onBridgeReady);\r\n        }\r\n    } else {\r\n        onBridgeReady();\r\n    }\r\n</script>\r\n',-1),
	(52,'个人资料表单','page.patient-me','<?php\r\n\r\n/* @var $this \\common\\extend\\View */\r\n/* @var $dataProvider \\yii\\data\\ActiveDataProvider */\r\n/* @var $model \\common\\models\\WebsiteConfig */\r\n\r\n?>\r\n<div class=\"ui-form ui-border-t\">\r\n    <?php $form = \\yii\\widgets\\ActiveForm::begin([\r\n        \'options\' => [\r\n            \'id\' => \'form\',\r\n        ],\r\n    ]) ?>\r\n    <div class=\"ui-form-item ui-border-b\">\r\n        <label>真实姓名</label>\r\n        <?= \\yii\\helpers\\Html::activeTextInput($model, \"name\", [\r\n            \'placeholder\' => \'真实姓名\',\r\n        ]) ?>\r\n    </div>\r\n\r\n    <div class=\"ui-form-item ui-border-b\">\r\n        <label>性别</label>\r\n        <div class=\"ui-select\">\r\n            <?= \\yii\\helpers\\Html::activeDropDownList($model, \"sex\", [\'女\', \'男\']) ?>\r\n        </div>\r\n    </div>\r\n\r\n\r\n    <div class=\"ui-form-item ui-border-b\">\r\n        <label>手机号</label>\r\n        <?= \\yii\\helpers\\Html::activeTextInput($model, \"phone\", [\r\n            \'placeholder\' => \'联系手机号\',\r\n        ]) ?>\r\n    </div>\r\n\r\n    <div class=\"ui-form-item ui-border-b\">\r\n        <label>成员关系</label>\r\n        <div class=\"ui-select\">\r\n            <?= \\yii\\helpers\\Html::activeDropDownList($model, \"relation\", \\common\\models\\MyPatient::relationList()); ?>\r\n        </div>\r\n    </div>\r\n\r\n    <div class=\"ui-form-item ui-border-b\">\r\n        <label>生日</label>\r\n        <div class=\"ui-select-group\">\r\n            <div class=\"ui-select\">\r\n                <?= \\yii\\helpers\\Html::activeDropDownList($model, \"birthYear\", \\common\\utils\\ListGenerator::year()) ?>\r\n            </div>\r\n            <div class=\"ui-select\">\r\n                <?= \\yii\\helpers\\Html::activeDropDownList($model, \"birthMonth\", \\common\\utils\\ListGenerator::month()) ?>\r\n            </div>\r\n            <div class=\"ui-select\">\r\n                <?= \\yii\\helpers\\Html::activeDropDownList($model, \"birthDay\", \\common\\utils\\ListGenerator::day()) ?>\r\n            </div>\r\n        </div>\r\n    </div>\r\n\r\n\r\n    <div class=\"ui-form-item ui-border-b\">\r\n        <label>身份证号</label>\r\n        <?= \\yii\\helpers\\Html::activeTextInput($model, \"identify\", [\r\n            \'pattern\' => \'\\d*\', \'placeholder\' => \"18或15位身份证号\", \'type\' => \'tel\',\r\n        ]) ?>\r\n    </div>\r\n\r\n\r\n    <div class=\"ui-form-item ui-border-b\">\r\n        <label>身高</label>\r\n        <?= \\yii\\helpers\\Html::activeTextInput($model, \"height\", [\r\n            \'pattern\' => \'\\d*\', \'placeholder\' => \"厘米\", \'type\' => \'tel\',\r\n        ]) ?>\r\n    </div>\r\n\r\n    <div class=\"ui-form-item ui-border-b\">\r\n        <label>体重</label>\r\n        <?= \\yii\\helpers\\Html::activeTextInput($model, \"weight\", [\r\n            \'pattern\' => \'\\d*\', \'placeholder\' => \"千克\", \'type\' => \'tel\',\r\n        ]) ?>\r\n    </div>\r\n    <?php \\yii\\widgets\\ActiveForm::end(); ?>\r\n</div>\r\n\r\n<script>\r\n    $(function () {\r\n        $(\"body\").on(\"click\", \"#action-btn-save\", function (e) {\r\n            e.preventDefault();\r\n            msgConfirm(\"请认真核对您的个人信息，保存后不可修改和删除，是否保存？\",function(){\r\n                $(\"#form\").submit();\r\n            });\r\n        });\r\n        \r\n        $(\'#form\').on(\'afterValidate\', function (event, messages, errorAttributes) {\r\n         for (field in messages){\r\n             if (messages[field].length > 0){\r\n                 msgTip(messages[field][0])\r\n             }\r\n         }\r\n     });\r\n    })\r\n</script>\r\n',0),
	(53,'会员卡详情介绍','card.detail','<?php\r\n/** @var $model \\common\\models\\MemberCard */\r\n?>\r\n<div class=\"ui-page-card-detail\">\r\n    <section class=\"card-show p-20\">\r\n        <img src=\"/images/card-detail-icon.png\" alt=\"\">\r\n        <div class=\"info\">\r\n            拥有<span><?= $model->name ?></span>可以享受以下特权\r\n        </div>\r\n    </section>\r\n    <section class=\"card-info mt-20\">\r\n        <?= $model->description ?>\r\n    </section>\r\n\r\n    <div class=\"button-group mt-20\">\r\n        <ul class=\"ui-tiled\">\r\n            <?php\r\n            $userID = \\common\\utils\\UserSession::getId();\r\n            if (\\common\\models\\MemberOwnCard::isUserHasCard($userID)) {\r\n                $userCard = \\common\\models\\MemberOwnCard::getUserEnableCard($userID);\r\n                if ($userCard->memberCard->order > $model->order) {\r\n                    ?>\r\n                    <li style=\"padding-left: 20px;\">\r\n                        <a href=\"/card/buy?id=<?= $model->id ?>\" class=\"btn-upgrade\">升级</a>\r\n                    </li>\r\n                    <?php\r\n                } else {\r\n                    ?>\r\n                    <li style=\"padding-right: 20px;\">\r\n                        <a href=\"/card/charge\" class=\"btn-charge\">充值</a>\r\n                    </li>\r\n                    <?php\r\n\r\n                }\r\n                ?>\r\n                <?php\r\n            } else {\r\n                $buyPrice = sprintf(\"%0.2f\", $model->price * $model->discount / 100);\r\n                ?>\r\n                <li style=\"padding-right: 20px;\">\r\n                    <a href=\"/card/buy?id=<?= $model->id ?>\" class=\"btn-charge\">&yen; <?= $buyPrice ?> &nbsp;充值</a>\r\n                </li>\r\n                <?php\r\n            }\r\n            ?>\r\n        </ul>\r\n    </div>\r\n</div>\r\n',0),
	(54,'我的订单列表','page.order-list','<?php\r\n\r\n/* @var $this \\common\\extend\\View */\r\n/* @var $dataProvider \\yii\\data\\ActiveDataProvider */\r\n/* @var $model \\common\\models\\Order */\r\n\r\n?>\r\n\r\n<div class=\"ui-order-list\">\r\n    <?php foreach ($models as $model) { ?>\r\n        <section class=\"ui-panel mt-20\">\r\n            <div class=\"ui-panel-heading flex-show\">\r\n                <div class=\"title\">\r\n                    <?= $model->name ?>\r\n                </div>\r\n                <div class=\"price\">\r\n                    &yen;<?= $model->getPriceYuan() ?>\r\n                </div>\r\n            </div>\r\n            <div class=\"ui-panel-body ui-align-right\">\r\n                <?php\r\n                switch ($model->status) {\r\n                    case \\common\\models\\Order::STATUS_PENDING_PAY:\r\n                        echo \\yii\\helpers\\Html::a(\"取消订单\", [\'order/cancel-pay\', \'id\' => $model->order_id], [\r\n                            \'class\' => \'ui-btn ui-btn-danger mr-10 action-btn-cancel\',\r\n                        ]);\r\n                        echo \\yii\\helpers\\Html::a(\"立即支付\", [\'pay/index\', \'id\' => $model->order_id], [\r\n                            \'class\' => \'ui-btn ui-btn-primary ui-btn-main\',\r\n                        ]);\r\n                        break;\r\n                    case \\common\\models\\Order::STATUS_PAY_CLOSED:\r\n                        echo \\yii\\helpers\\Html::tag(\"span\", \"已关闭\");\r\n                        break;\r\n                    case \\common\\models\\Order::STATUS_PAY_REFUND:\r\n                        echo \\yii\\helpers\\Html::tag(\"span\", \"已退款\");\r\n                        break;\r\n                    case \\common\\models\\Order::STATUS_PAY_SUCCESS:\r\n                        echo \\yii\\helpers\\Html::tag(\"span\", \"支付成功\");\r\n                        break;\r\n                }\r\n                ?>\r\n            </div>\r\n        </section>\r\n    <?php } ?>\r\n</div>\r\n',0),
	(55,'日历展示','element.calendar','<?php\r\n\r\nuse yii\\helpers\\Html;\r\n\r\n/** @var  $prevMonth array */\r\n/** @var  $nextMonth array */\r\n/** @var  $showPrevLink bool */\r\n/** @var  $doctorID integer */\r\n/** @var  $currentMonth string */\r\n/** @var  $calendarHtml string */\r\n\r\n$prevMonthLink = [\r\n    \"/service-calendar\",\r\n    \'year\'  => $prevMonth[\'year\'],\r\n    \'month\' => $prevMonth[\'month\'],\r\n    \'id\'    => $doctorID,\r\n];\r\n\r\n$nextMonthLink = [\r\n    \"/service-calendar\",\r\n    \'year\'  => $nextMonth[\'year\'],\r\n    \'month\' => $nextMonth[\'month\'],\r\n    \'id\'    => $doctorID,\r\n];\r\n?>\r\n<div class=\"panel panel-default\">\r\n    <div class=\"panel-heading clearfix\">\r\n        <strong><?= $currentMonth ?></strong>\r\n        <div class=\"pull-right\">\r\n            <?= $showPrevLink == true ? Html::a(\"上一月\", $prevMonthLink) : \"\" ?>\r\n            <?= Html::a(\"下一月\", $nextMonthLink) ?>\r\n        </div>\r\n    </div>\r\n    <?= $calendarHtml ?>\r\n</div>\r\n',0),
	(56,'支付成功','page.pay-success','<div>\r\n        <div class=\"ui-align-center\" style=\"margin-top: 30%\">\r\n            <i class=\"ui-icon-success\" style=\"color: green; font-size: 150px\"></i>\r\n            <h1 class=\"mt-50\" style=\"font-size: 30px\">支付成功</h1>\r\n        </div>\r\n</div>',0),
	(57,'个人中心-充值提示','element.me.alert-tip','<section class=\"ui-alert-tips\">\r\n    <i><img src=\"/images/icon-alert.png\" /></i>\r\n    <span>会员卡在线充值&nbsp;<a href=\"/card/charge\">立即充值></a></span>\r\n</section>',4004),
	(58,'取消预约页面','page.appointment.cancel','<div class=\"ui-panel\">\r\n    <div class=\"ui-panel-body\">\r\n        这里填写取消预约需要知道\r\n    </div>\r\n</div>',0),
	(59,'理疗预约','page.liliao','<div class=\"ui-page-liliao\">\r\n    <div class=\"banner-show\">\r\n\r\n    </div>\r\n\r\n    {% element.liliao.item-list %}\r\n    \r\n</div>',0),
	(60,'理疗预约-项目列表','element.liliao.item-list','<?php\r\n$liliaoList = \\common\\utils\\Cache::getOrSet(\"liliao-list\", function () {\r\n    $list = \\common\\models\\Doctor::find()\r\n                                 ->where([\'type\' => \\common\\models\\Doctor::TYPE_LILIAO])\r\n                                 ->asArray()\r\n                                 ->all();\r\n\r\n    return $list;\r\n})\r\n?>\r\n\r\n<ul class=\"list\">\r\n    <?php foreach ($liliaoList as $item): ?>\r\n        <li>\r\n            <div class=\"head\">\r\n                <?= \\yii\\helpers\\Html::img($item[\'head_image\']) ?>\r\n            </div>\r\n            <div class=\"info\">\r\n                <div class=\"title\"><?= $item[\'name\'] ?></div>\r\n                <div class=\"ui-txt-info\"><?= $item[\'summary\'] ?></div>\r\n                <div class=\"footer\">\r\n                    <div class=\"price\">&yen;<?= $item[\'ask_price\'] ?></div>\r\n                    <div class=\"detail\">\r\n                        <span class=\"ui-txt-info\">已售500</span>\r\n                        <?= \\yii\\helpers\\Html::a(\'立即咨询\',\r\n                            [\'/doctor/index\', \'id\' => $item[\'id\']],\r\n                            [\r\n                                \'class\' => \'ui-btn ui-btn-orange\',\r\n                            ]) ?>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </li>\r\n    <?php endforeach; ?>\r\n</ul>',0),
	(61,'收货地址列表','page.address-list','<?php\r\n/** @var \\common\\models\\Address $item */\r\n?>\r\n<div class=\"ui-page-address-list\">\r\n    <?php foreach ($list as $item): ?>\r\n        <div class=\"ui-panel mt-20\">\r\n            <div class=\"ui-panel-heading ui-border-b\">\r\n                <div class=\"name-phone\">\r\n                    <span><?= $item->name ?></span>\r\n                    <span><?= $item->phone ?></span>\r\n                </div>\r\n                <div class=\"mt-10\"><?=$item->location?></div>\r\n            </div>\r\n            <div class=\"ui-panel-body\">\r\n                <div class=\"default\">\r\n                    <?php if ($item->default) { ?>\r\n                        <button class=\"ui-btn-s ui-btn-main action-set-default\" data-id=\"<?= $item->id ?>\">默认地址</button>\r\n                    <?php } else { ?>\r\n                        <button class=\"ui-btn-s  action-set-default\" data-id=\"<?= $item->id ?>\">默认地址</button>\r\n                    <?php } ?>\r\n                </div>\r\n                <div class=\"action-btn-list\">\r\n                    <?= \\yii\\helpers\\Html::a(\"编辑\", [\'/address/update\', \'id\' => $item->id], [\'class\' => \'ui-btn-s\']) ?>\r\n                    <?= \\yii\\helpers\\Html::button(\"删除\", [\r\n                        \'class\'   => \'ui-btn-s ui-btn-danger action-remove\',\r\n                        \'data-id\' => $item->id,\r\n                    ]) ?>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    <?php endforeach; ?>\r\n\r\n    <div class=\"btn-wrapper\">\r\n        <a class=\"ui-btn-lg ui-btn-main\" href=\"<?= \\yii\\helpers\\Url::to([\"/address/create\"]) ?>\">添加新地址</a>\r\n    </div>\r\n</div>\r\n\r\n\r\n<script>\r\n    $(function () {\r\n        // set default\r\n        $(\"body\").on(\"click\", \".action-set-default\", function () {\r\n            $.get(\"/address/set-default\", {id: $(this).attr(\"data-id\")}, function (data) {\r\n                $(\".ui-btn-s\").removeClass(\"ui-btn-main\");\r\n                $(this).addClass(\"ui-btn-main\")\r\n            }.bind(this));\r\n        });\r\n\r\n        // remove\r\n        $(\"body\").on(\"click\", \".action-remove\", function () {\r\n            if (!confirm(\"确认删除此用户？\")) {\r\n                return false;\r\n            }\r\n\r\n            $.get(\"/address/delete\", {id: $(this).attr(\"data-id\")}, function (data) {\r\n                $(this).closest(\".ui-panel\").remove();\r\n                msgTip(\"删除成功\");\r\n            }.bind(this));\r\n        });\r\n    });\r\n</script>',0),
	(62,'收货地址表单','page.address-form','<?php $form = \\yii\\widgets\\ActiveForm::begin([\r\n    \'options\' => [\r\n        \'id\' => \'form\',\r\n    ],\r\n]) ?>\r\n<div class=\"ui-form ui-border-t\">\r\n    <div class=\"ui-form-item ui-border-b\">\r\n        <label>收货人</label>\r\n        <?= \\yii\\helpers\\Html::activeTextInput($model, \"name\") ?>\r\n    </div>\r\n\r\n    <div class=\"ui-form-item ui-border-b\">\r\n        <label>联系电话</label>\r\n        <?= \\yii\\helpers\\Html::activeTextInput($model, \"phone\") ?>\r\n    </div>\r\n\r\n\r\n    <div class=\"ui-form-item ui-border-b\">\r\n        <label>收货地址</label>\r\n        <?= \\yii\\helpers\\Html::activeTextInput($model, \"location\") ?>\r\n    </div>\r\n</div>\r\n\r\n<div class=\"p-20\">\r\n    <?= \\yii\\helpers\\Html::submitButton(\"保存\", [\r\n        \'class\' => \'ui-btn-lg ui-btn-main\',\r\n    ]) ?>\r\n</div>\r\n<?php \\yii\\widgets\\ActiveForm::end(); ?>\r\n\r\n<script>\r\n    $(function () {\r\n        $(\'#form\').on(\'afterValidate\', function (event, messages, errorAttributes) {\r\n            for (field in messages) {\r\n                if (messages[field].length > 0) {\r\n                    msgTip(messages[field][0])\r\n                }\r\n            }\r\n        });\r\n    });\r\n</script>',0),
	(63,'我的积分','page.coin','<?php\r\n$coinCount = intval(\\common\\utils\\UserSession::identity()->coin->coin);\r\n?>\r\n<div class=\"ui-page-my-coin\">\r\n    <div class=\"ui-alert-tips\">\r\n        <i><img src=\"/images/icon-alert.png\"/></i>\r\n        <span>汉典中医积分系统上线啦！<a href=\"/coin/rule\">查看积分规则</a></span>\r\n    </div>\r\n\r\n    <div class=\"coin-show ui-txt-center\">\r\n        <div class=\"ui-txt-info\">积分</div>\r\n        <h1><?= $coinCount ?></h1>\r\n    </div>\r\n</div>\r\n',0),
	(64,'积分规则','page.coin-rule','<div class=\"ui-panel mt-20\">\r\n    <div class=\"ui-panel-body\">\r\n        积分规则说明页面\r\n    </div>\r\n</div>\r\n',0),
	(65,'我的会员卡','card.mine','<div class=\"ui-page-my-card\">\r\n    <div class=\"card-img mb-20\">\r\n        <img src=\"<?=$model->card->getOption(\"image\")?>\" alt=\"\">\r\n    </div>\r\n\r\n    <div class=\"icon-show\">\r\n        <ul class=\"ui-tiled\">\r\n            <li class=\"ui-txt-center\" style=\"border-right: 1px solid #efefef\">\r\n                <i class=\"ui-icon-wallet\"></i>\r\n                <div class=\"ui-txt-info\">余额</div>\r\n                <div class=\"money\">&yen; <?= $model->remain_money; ?></div>\r\n            </li>\r\n            <li class=\"ui-text-center\">\r\n                <?php if ($model->card->isTopCard()){?>\r\n                <a href=\"javascript:msgTip(\'已经是最高等级会员卡，不可升级\')\">\r\n                    <?php }else{?>\r\n                <a href=\"/card/index?mode=upgrade\">\r\n                    <?php }?>\r\n                    <i class=\"ui-icon-gototop\"></i>\r\n                    <div class=\"ui-txt-info\">VIP</div>\r\n                    <div class=\"money\">升级</div>\r\n                </a>\r\n            </li>\r\n        </ul>\r\n    </div>\r\n\r\n    <div class=\"info\">\r\n        <div class=\"item flex-item phone\">\r\n            <div class=\"label\">手机</div>\r\n            <div class=\"data\">\r\n                <?= $model->user->phone ?>\r\n            </div>\r\n        </div>\r\n        <a href=\"/card/history\" class=\"item ui-arrowlink\">\r\n            账单\r\n        </a>\r\n        <div class=\"item info\">\r\n            <?= $model->card->description ?>\r\n        </div>\r\n    </div>\r\n</div>\r\n',0),
	(66,'会员卡使用须知','page.card-rules','<div class=\"ui-panel mt-20\">\r\n    <div class=\"ui-panel-body\">\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n        <p>会员卡使用须知</p>\r\n    </div>\r\n</div>',0),
	(67,'会员卡充值','page.card-charge','<div class=\"ui-page-card-charge\">\r\n    <?php $form = \\yii\\widgets\\ActiveForm::begin() ?>\r\n    <div class=\"widget card-info ui-align-center\">\r\n        <h1>当前余额 &yen; <?= $model->remain_money ?></h1>\r\n\r\n        <div class=\"card-charge-amount mt-20\">\r\n            <?= \\yii\\helpers\\Html::textInput(\"amount\", \"\", [\r\n                \'autofocus\' => true,\r\n                \'pattern\'   => \'\\d*\',\r\n                \'type\'      => \'tel\',\r\n            ]) ?>\r\n        </div>\r\n    </div>\r\n\r\n    <div class=\"widget mt-20\">\r\n        <?= \\yii\\helpers\\Html::submitButton(\"提交\", [\'class\' => \'ui-btn-lg ui-btn-main\']) ?>\r\n    </div>\r\n    <?php \\yii\\widgets\\ActiveForm::end() ?>\r\n</div>\r\n\r\n<script>\r\n    <?php\r\n    if ($model->hasErrors()) {\r\n        $error = implode(\",\", $model->getFirstErrors());\r\n        /** @var $this \\common\\extend\\View */\r\n        $this->registerJs(sprintf(\"msgTip(\'%s\')\", $error));\r\n    }\r\n    ?>\r\n</script>\r\n',0),
	(68,'在线咨询入口','page.ask-show','<?php\r\n$linkList = \\common\\models\\LinkGroup::getLinkItems(\"online-ask-department-list\");\r\n?>\r\n<div class=\"page-ask-show\">\r\n    <div class=\"show-banner\">\r\n\r\n    </div>\r\n\r\n        <form action=\"/appointment/ask\" method=\"get\">\r\n    <div class=\"search-box\">\r\n        <div class=\"search-input-container\">\r\n            <div class=\"search-input-wrapper\">\r\n                <i class=\"ui-icon-search\"></i>\r\n                <input type=\"text\" name=\"department\" class=\"search-input-box\">\r\n            </div>\r\n        </div>\r\n        <div class=\"search-btn\">\r\n            <input class=\"ui-btn-s ui-btn-main\" value=\"搜索\" type=\"submit\">\r\n        </div>\r\n    </div>\r\n        </form>\r\n\r\n    <div class=\"comment-show\">\r\n        <ul class=\"ui-tiled\">\r\n            <li class=\"item first\">\r\n                <div class=\"title\">\r\n                    <i class=\"ui-icon-commented\"></i>\r\n                    <span>快速咨询</span>\r\n                </div>\r\n                <div class=\"info\">\r\n                    30秒内医生快速回答\r\n                </div>\r\n            </li>\r\n\r\n            <li class=\"item\">\r\n                <div class=\"title\">\r\n                    <i class=\"ui-icon-personal\"></i>\r\n                    <span>名医咨询</span>\r\n                </div>\r\n                <div class=\"info\">\r\n                    国家级名老中医回复\r\n                </div>\r\n            </li>\r\n        </ul>\r\n    </div>\r\n\r\n    <div class=\"department-list\">\r\n        <h2>按科室找医生</h2>\r\n        <div class=\"row ui-9-grids-wrapper\">\r\n            <div class=\"ui-9-grids\">\r\n                <?php foreach ($linkList as $linkItem): ?>\r\n                    <a href=\"<?= $linkItem->getUrl() ?>\" class=\"ui-item\">\r\n                        <p class=\"ui-grid-label\"><?=$linkItem->name?></p>\r\n                    </a>\r\n                <?php endforeach; ?>\r\n            </div>\r\n        </div>\r\n    </div>\r\n\r\n    <div class=\"ask-list\">\r\n        <h2>咨询动态</h2>\r\n        <ul>\r\n            <?php for ($i = 0; $i < 10; $i++): ?>\r\n                <li>\r\n                    <a href=\"#\" class=\"head\"><img src=\"/images/grid-0.png\" alt=\"\"></a>\r\n                    <div class=\"doctor-info\">\r\n                        <div class=\"name\">徐润三 国医大师</div>\r\n                        <div class=\"info\">张三 刚刚向专家发起了提问</div>\r\n                    </div>\r\n                    <div class=\"time\">\r\n                        刚刚\r\n                    </div>\r\n                </li>\r\n            <?php endfor; ?>\r\n        </ul>\r\n    </div>\r\n</div>',0),
	(69,'会员卡消费记录','page.card-history','<div class=\"ui-page-card-history\">\r\n    <?php foreach ($models as $model): ?>\r\n        <div class=\"ui-panel\">\r\n            <div class=\"ui-panel-heading flex-show\">\r\n                <?= $model->order->name ?>\r\n                <span class=\"ui-txt-info\">\r\n                    <?= date(\"Y-m-d H:i\", $model->created_at) ?>\r\n                </span>\r\n            </div>\r\n            <div class=\"ui-panel-body\">\r\n                <div class=\"ui-txt-size-18 ui-align-right\">- &yen;<?= $model->pay_price ?></div>\r\n            </div>\r\n        </div>\r\n    <?php endforeach; ?>\r\n</div>',0),
	(70,'预约详情','page.appointment-detail','<?php\r\n/** @var $model \\common\\models\\DoctorAppointment */\r\n/** @var \\common\\models\\Order $orderInfo */\r\n$orderID        = \\common\\models\\OrderMontData::getOrderIDByName(\\common\\models\\DoctorAppointment::rawTableName(), $model->id);\r\n$orderInfo      = \\common\\models\\Order::findOne($orderID);\r\n$departmentInfo = $orderInfo->montData(\\common\\models\\Department::rawTableName());\r\n$department     = \\common\\models\\Department::getByID($departmentInfo->content);\r\n?>\r\n<div class=\"ui-page-appointment-cancel\">\r\n    <div class=\"widget doctor-info mb-20\">\r\n        <?= \\yii\\helpers\\Html::img($model->doctor->head_image) ?>\r\n        <div class=\"info\">\r\n            <?= sprintf(\"<span class=\'name\'>%s</span> %s\", $model->doctor->name, $model->doctor->levelModel->level_name) ?>\r\n        </div>\r\n    </div>\r\n\r\n    <ul class=\"widget-item-list mb-20\">\r\n        <li>\r\n            <div class=\"label\">就诊医院</div>\r\n            <div class=\"data\">汉典中医医院</div>\r\n        </li>\r\n        <li>\r\n            <div class=\"label\">就诊科室</div>\r\n            <div class=\"data\"><?= $department->name ?></div>\r\n        </li>\r\n        <li>\r\n            <div class=\"label\">就诊地址</div>\r\n            <div class=\"data\">朝阳区石佛营东里133号</div>\r\n        </li>\r\n        <li>\r\n            <div class=\"label\">预约时间</div>\r\n            <div class=\"data\"><?= date(\"Y-m-d H:i\", $model->time_begin) ?></div>\r\n        </li>\r\n    </ul>\r\n\r\n    <ul class=\"widget-item-list\">\r\n        <li>\r\n            <div class=\"label\">就诊人</div>\r\n            <div class=\"data\"><?= $model->patientInfo->name ?></div>\r\n        </li>\r\n        <li>\r\n            <div class=\"label\">性别</div>\r\n            <div class=\"data\"><?= [\'女\', \'男\'][$model->patientInfo->sex] ?></div>\r\n        </li>\r\n        <li>\r\n            <div class=\"label\">生日</div>\r\n            <div class=\"data\"><?= $model->patientInfo->birth ?></div>\r\n        </li>\r\n        <li>\r\n            <div class=\"label\">预约手机</div>\r\n            <div class=\"data\"><?= $model->patientInfo->phone ?></div>\r\n        </li>\r\n    </ul>\r\n\r\n    <ul class=\"widget-item-list\">\r\n        <li>\r\n            <div class=\"label\">支付方式</div>\r\n            <div class=\"data\"><?= \\common\\models\\Order::channelName($model->order->channel) ?></div>\r\n        </li>\r\n        <li>\r\n            <div class=\"label\">下单时间</div>\r\n            <div class=\"data\"><?= date(\"Y-m-d H:i\", $model->order->created_at) ?></div>\r\n        </li>\r\n    </ul>\r\n\r\n    <div class=\"m-20 ui-txt-info\">\r\n        温馨提示：取消预约前请认真阅读 <a href=\"/appointment/cancel\">取消预约须知</a>\r\n    </div>\r\n\r\n    <div class=\"widget\">\r\n        <a href=\"/appointment/cancel-order?id=<?= $model->id ?>\" onclick=\"return confirm(\'确定要取消预约么？\')\"\r\n           class=\"ui-btn-lg ui-btn-main\">取消预约</a>\r\n    </div>\r\n</div>',0),
	(71,'医生筛选','element.doctor_filter','<?php\r\n$departments = \\common\\models\\Department::find()->all();\r\n$orderType   = [\r\n    \'default\' => \'默认排序\',\r\n    \'mark\'    => \'评分排序\',\r\n];\r\n\r\n$departmentMap   = \\yii\\helpers\\ArrayHelper::map($departments, \"id\", \"name\");\r\n$orderValue      = \\common\\utils\\Request::input(\"order\", \"default\");\r\n$departmentValue = \\common\\utils\\Request::input(\"department\", \"\");\r\n?>\r\n<div class=\"doctor-filter-box\">\r\n    <div class=\"doctor-filter\">\r\n        <div class=\"item department-filter\"\r\n             data-id=\"department-filter-items\"><?= empty($departmentValue) ? \"全部科室\" : $departmentValue ?></div>\r\n        <div class=\"item sort-filter\" data-id=\"sort-filter-items\"><?= $orderType[$orderValue] ?></div>\r\n    </div>\r\n    <div class=\"filter-mask\"></div>\r\n    <div class=\"doctor-filter-items\">\r\n        <div class=\"filter-item\" id=\"department-filter-items\">\r\n            <?php\r\n            echo \\yii\\helpers\\Html::a(\"全部科室\", [$this->uniqueID, \'department\' => \"\"], [\r\n                \'class\' => \'ui-btn ui-btn-main\',\r\n            ]);\r\n\r\n            foreach ($departments as $department) {\r\n                echo \\yii\\helpers\\Html::a($department->name, [$this->uniqueID, \'department\' => $department->name], [\r\n                    \'class\' => \'ui-btn ui-btn-main\',\r\n                ]);\r\n            }\r\n            ?>\r\n        </div>\r\n        <div class=\"filter-item\" id=\"sort-filter-items\">\r\n            <?php\r\n            foreach ($orderType as $key => $value) {\r\n                echo \\yii\\helpers\\Html::a($value, [\"/appointment/ask\", \'order\' => $key], [\r\n                    \'class\' => \'ui-btn ui-btn-main\',\r\n                ]);\r\n            }\r\n            ?>\r\n        </div>\r\n    </div>\r\n</div>\r\n<script>\r\n    $(function () {\r\n        $(\"body\").on(\"tap\", \".doctor-filter .item\", function () {\r\n            $(\".filter-item\").hide();\r\n\r\n            var targetID = $(this).attr(\"data-id\");\r\n            $(\"#\" + targetID).toggle();\r\n            $(\".filter-mask\").show();\r\n        });\r\n\r\n        $(\"body\").on(\"tap\", \".filter-mask\", function () {\r\n            $(this).hide();\r\n            $(\".filter-item\").hide();\r\n        });\r\n    })\r\n</script>\r\n',0);

/*!40000 ALTER TABLE `code_block` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table department
# ------------------------------------------------------------

DROP TABLE IF EXISTS `department`;

CREATE TABLE `department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;

INSERT INTO `department` (`id`, `name`)
VALUES
	(1,'妇科'),
	(2,'男科'),
	(3,'心科'),
	(4,'消化道');

/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table doctor
# ------------------------------------------------------------

DROP TABLE IF EXISTS `doctor`;

CREATE TABLE `doctor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `head_image` varchar(255) NOT NULL DEFAULT '',
  `level` int(11) NOT NULL DEFAULT '1',
  `name` varchar(255) NOT NULL,
  `summary` text,
  `work_time` int(11) DEFAULT NULL,
  `introduce` text,
  `rank` varchar(255) NOT NULL DEFAULT '0',
  `enable_ask` tinyint(1) NOT NULL DEFAULT '0',
  `ask_price` int(11) NOT NULL DEFAULT '20',
  `type` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `doctor` WRITE;
/*!40000 ALTER TABLE `doctor` DISABLE KEYS */;

INSERT INTO `doctor` (`id`, `head_image`, `level`, `name`, `summary`, `work_time`, `introduce`, `rank`, `enable_ask`, `ask_price`, `type`)
VALUES
	(1,'/upload/2017/12/28/96e89a298e0a9f469b9ae458d6afae9f.jpg',1,' 杨豪豪',' 我不是一个美男子， 我不是一个美男子， 我不是一个美男子， 我不是一个美男子。',12,'<p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p style=\"white-space: normal;\">这里是医生详细介绍</p><p><br/></p>','5',1,20,0),
	(2,'/upload/2017/12/28/78805a221a988e79ef3f42d7c5bfd418.jpg',3,'李小小','我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，',10,'<p style=\"white-space: normal;\">我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，</p><p style=\"white-space: normal;\"><br/></p><p style=\"white-space: normal;\">我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，</p><p style=\"white-space: normal;\"><br/></p><p style=\"white-space: normal;\">我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，</p><p style=\"white-space: normal;\"><br/></p><p style=\"white-space: normal;\">我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，我是李小小，</p><p style=\"white-space: normal;\"><br/></p><p><br/></p>','3',0,20,0),
	(3,'/upload/2018/02/06/78805a221a988e79ef3f42d7c5bfd418.jpg',1,'我是一个理疗项目','asdf',12,'<p>asdfasdf</p>','12',1,123,1);

/*!40000 ALTER TABLE `doctor` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table doctor_appointment
# ------------------------------------------------------------

DROP TABLE IF EXISTS `doctor_appointment`;

CREATE TABLE `doctor_appointment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `doctor_id` int(11) NOT NULL,
  `time_begin` int(11) NOT NULL DEFAULT '0',
  `time_end` int(11) NOT NULL DEFAULT '0',
  `order_number` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `feedback_at` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `doctor_appointment` WRITE;
/*!40000 ALTER TABLE `doctor_appointment` DISABLE KEYS */;

INSERT INTO `doctor_appointment` (`id`, `user_id`, `patient_id`, `doctor_id`, `time_begin`, `time_end`, `order_number`, `status`, `created_at`, `updated_at`, `feedback_at`)
VALUES
	(3,1,1,1,1514764800,1514779200,1,0,1514728974,1514728974,0),
	(4,1,1,1,1514764800,1514779200,2,1,1514729091,1514729091,0),
	(5,1,1,1,1514764800,1514779200,3,1,1514729105,1514729105,0),
	(6,1,1,1,1514764800,1514779200,4,1,1514729139,1514729139,0),
	(11,1,7,1,1515542400,1515556800,1,1,1515515086,1515515086,0),
	(12,1,2,1,1516060800,1516075200,1,1,1515921545,1515921545,0),
	(13,3,6,1,1515974400,1515988800,1,1,1515929116,1515929116,0),
	(18,1,2,1,1517961600,1517976000,1,1,1518012835,1518012835,0),
	(19,1,2,1,1521590400,1521604800,1,0,1521550957,1521550957,0),
	(20,1,2,1,1521590400,1521604800,2,2,1521551516,1521553815,0);

/*!40000 ALTER TABLE `doctor_appointment` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table doctor_appointment_patient_info
# ------------------------------------------------------------

DROP TABLE IF EXISTS `doctor_appointment_patient_info`;

CREATE TABLE `doctor_appointment_patient_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appointment_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL DEFAULT '',
  `memo` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `doctor_appointment_patient_info` WRITE;
/*!40000 ALTER TABLE `doctor_appointment_patient_info` DISABLE KEYS */;

INSERT INTO `doctor_appointment_patient_info` (`id`, `appointment_id`, `username`, `phone`, `memo`)
VALUES
	(1,1,'杨小九','123','123');

/*!40000 ALTER TABLE `doctor_appointment_patient_info` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table doctor_appointment_track
# ------------------------------------------------------------

DROP TABLE IF EXISTS `doctor_appointment_track`;

CREATE TABLE `doctor_appointment_track` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `appointment_id` int(11) NOT NULL,
  `track_message` varchar(255) NOT NULL DEFAULT '',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table doctor_department
# ------------------------------------------------------------

DROP TABLE IF EXISTS `doctor_department`;

CREATE TABLE `doctor_department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doctor_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `doctor_department` WRITE;
/*!40000 ALTER TABLE `doctor_department` DISABLE KEYS */;

INSERT INTO `doctor_department` (`id`, `doctor_id`, `department_id`)
VALUES
	(3,1,1),
	(4,1,2),
	(5,1,4),
	(6,2,1),
	(7,2,3),
	(8,2,4),
	(9,3,1),
	(10,3,4);

/*!40000 ALTER TABLE `doctor_department` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table doctor_level
# ------------------------------------------------------------

DROP TABLE IF EXISTS `doctor_level`;

CREATE TABLE `doctor_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level_name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `doctor_level` WRITE;
/*!40000 ALTER TABLE `doctor_level` DISABLE KEYS */;

INSERT INTO `doctor_level` (`id`, `level_name`)
VALUES
	(1,'主任医师'),
	(2,'国医大师'),
	(3,'京医大师');

/*!40000 ALTER TABLE `doctor_level` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table doctor_service_time
# ------------------------------------------------------------

DROP TABLE IF EXISTS `doctor_service_time`;

CREATE TABLE `doctor_service_time` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doctor_id` int(11) NOT NULL,
  `ticket_count` int(11) NOT NULL DEFAULT '0',
  `mode` varchar(255) NOT NULL DEFAULT '0',
  `month` varchar(255) NOT NULL,
  `week` varchar(255) NOT NULL DEFAULT '0',
  `week_service_start_at` varchar(255) NOT NULL DEFAULT '0',
  `day` varchar(255) NOT NULL,
  `am` varchar(255) NOT NULL,
  `pm` varchar(255) NOT NULL,
  `max_time_long` varchar(255) NOT NULL DEFAULT '0',
  `price` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `doctor_service_time` WRITE;
/*!40000 ALTER TABLE `doctor_service_time` DISABLE KEYS */;

INSERT INTO `doctor_service_time` (`id`, `doctor_id`, `ticket_count`, `mode`, `month`, `week`, `week_service_start_at`, `day`, `am`, `pm`, `max_time_long`, `price`)
VALUES
	(1,1,50,'0','\"\"','0','{\"year\":\"2017\",\"month\":\"1\",\"day\":\"1\"}','[\"1\",\"3\",\"5\"]','{\"begin\":\"8\",\"end\":\"12\"}','{\"begin\":\"12\",\"end\":\"12\"}','5',128),
	(2,2,12,'0','\"\"','0','{\"year\":\"2017\",\"month\":\"1\",\"day\":\"1\"}','[\"2\",\"4\",\"6\"]','{\"begin\":\"8\",\"end\":\"12\"}','{\"begin\":\"12\",\"end\":\"12\"}','5',198);

/*!40000 ALTER TABLE `doctor_service_time` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table doctor_service_time_range
# ------------------------------------------------------------

DROP TABLE IF EXISTS `doctor_service_time_range`;

CREATE TABLE `doctor_service_time_range` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doctor_id` int(11) NOT NULL,
  `begin` varchar(255) NOT NULL,
  `end` varchar(255) NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `doctor_service_time_range` WRITE;
/*!40000 ALTER TABLE `doctor_service_time_range` DISABLE KEYS */;

INSERT INTO `doctor_service_time_range` (`id`, `doctor_id`, `begin`, `end`, `count`)
VALUES
	(1,1,'8:30','19:00',10),
	(2,1,'9:00','9:30',10),
	(3,1,'9:30','10:00',10),
	(4,1,'10:00','10:30',10),
	(5,1,'11:00','11:30',10),
	(6,1,'11:30','12:00',10);

/*!40000 ALTER TABLE `doctor_service_time_range` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table doctor_tag
# ------------------------------------------------------------

DROP TABLE IF EXISTS `doctor_tag`;

CREATE TABLE `doctor_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doctor_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `doctor_tag` WRITE;
/*!40000 ALTER TABLE `doctor_tag` DISABLE KEYS */;

INSERT INTO `doctor_tag` (`id`, `doctor_id`, `name`)
VALUES
	(8,'2','不好看'),
	(9,'2','好看'),
	(10,'2','没钱'),
	(11,'1','好看'),
	(12,'1','长的帅'),
	(13,'1','有钱'),
	(14,'1','还是有钱'),
	(15,'1','美男子'),
	(16,'1','小鲜肉'),
	(17,'1','小可爱'),
	(18,'1','小清新'),
	(19,'3','asdf');

/*!40000 ALTER TABLE `doctor_tag` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table link_group
# ------------------------------------------------------------

DROP TABLE IF EXISTS `link_group`;

CREATE TABLE `link_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `slug` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `link_group` WRITE;
/*!40000 ALTER TABLE `link_group` DISABLE KEYS */;

INSERT INTO `link_group` (`id`, `name`, `slug`)
VALUES
	(1,'首页九宫格','index.9-grid'),
	(2,'全局底部TabBar','site.tabbar'),
	(3,'个人中心IconBar','me.iconbar'),
	(4,'个人中心链接列表','me.link-list'),
	(5,'首页滚动Banner','index.carousel'),
	(6,'支付通道 ','pay-channel'),
	(7,'在线问诊科室列表','online-ask-department-list');

/*!40000 ALTER TABLE `link_group` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table link_group_item
# ------------------------------------------------------------

DROP TABLE IF EXISTS `link_group_item`;

CREATE TABLE `link_group_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `link_group_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `slug` varchar(255) NOT NULL DEFAULT '',
  `type` int(11) NOT NULL DEFAULT '0',
  `pid` int(11) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL DEFAULT '0',
  `data` varchar(255) NOT NULL DEFAULT '',
  `options` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `link_group_item` WRITE;
/*!40000 ALTER TABLE `link_group_item` DISABLE KEYS */;

INSERT INTO `link_group_item` (`id`, `link_group_id`, `name`, `slug`, `type`, `pid`, `order`, `data`, `options`)
VALUES
	(1,1,'门诊预约','59fd6d13224951d4813fc02ec9b2c3ca',0,0,0,'[\"/appointment/list\"]','{\r\n    \"image\":\"/images/grid-0.png\"\r\n}'),
	(2,1,'在线问诊','941d117ab855b23732d4f481301b50a6',2,0,0,'[\"/appointment/ask-show\"]','{\r\n    \"image\":\"/images/grid-1.png\"\r\n}'),
	(3,1,'一键复诊','8750860848881a9525c4ccad0151e836',2,0,0,'[\"/appointment/again\"]','{\r\n    \"image\":\"/images/grid-2.png\"\r\n}'),
	(4,1,'理疗预约','7c5eeabf70b7e6365fe580449619240c',0,0,0,'[\"/li-liao/list\"]','{\r\n    \"image\":\"/images/grid-3.png\"\r\n}'),
	(5,1,'品质中药','7128d8dd38238917973a3b6e8285dea2',2,0,0,'[\"/zhong-yao\"]','{\r\n    \"image\":\"/images/grid-4.png\"\r\n}'),
	(6,1,'会员优惠','3c270f0b43348c48e3fa42368a4c51b6',2,0,0,'[\"/card/index\"]','{\r\n    \"image\":\"/images/grid-5.png?id=2\"\r\n}'),
	(7,2,'首页','78065cc3f6acc6cf6c24a56565182220',0,0,0,'[\"/index/index\"]','{\r\n    \"icon\" :\"/images/tab-0.png\",\r\n    \"active_icon\":\"/images/active-tab-0.png\"\r\n}'),
	(8,2,'在线问诊','33c51b54148381d6585a4a3f9e20cc8e',0,0,0,'[\"/appointment/ask-show\"]','{\r\n    \"icon\" :\"/images/tab-1.png\",\r\n    \"active_icon\":\"/images/active-tab-1.png\"\r\n}'),
	(9,2,'门诊预约','299cb10f5b9218e398b6786f087ea9d2',0,0,0,'[\"/appointment/list\"]','{\r\n    \"icon\" :\"/images/tab-2.png\",\r\n    \"active_icon\":\"/images/active-tab-2.png\"\r\n}'),
	(10,2,'个人中心','6da9903d2f692452b8081aec3a3bd935',0,0,0,'[\"/me/index\"]','{\r\n    \"icon\" :\"/images/tab-3.png\",\r\n    \"active_icon\":\"/images/active-tab-3.png\"\r\n}'),
	(11,3,'待评论','aba23af2765b3509c9e2428f627f42ff',0,0,0,'[\"/me/index\"]','{\r\n    \"url\":[\"/appointment/pending-feedback\"],\r\n    \"callback\":[\"\\\\common\\\\models\\\\DoctorAppointment\",\"getNeedFeedbackCount\"]\r\n}'),
	(12,3,'我的积分','42522d0b39bb1543b5ac39015076809a',0,0,0,'[\"/me/index\"]','{\r\n    \"url\":[\"/coin\"],\r\n    \"callback\":[\"\\\\common\\\\models\\\\UserCoin\",\"getCurrentUserCoin\"]\r\n}'),
	(13,4,'个人资料','ce54fb7087b8c8b197de6f06548c2501',0,0,0,'[\"/patient/me\"]',''),
	(14,4,'就诊人','10b5a5c1a00a92c364d6fd5983cb7b55',0,0,0,'[\"/patient\"]',''),
	(15,4,'我的咨询','36b87fc5a948f0864c0e79db9a4b89aa',0,0,0,'[\"/ask/list\"]',''),
	(16,4,'我的评价','1237ccad3ddcc23067639f54eb8a8ebf',0,0,0,'[\"/appointment/feedback-list\"]',''),
	(17,4,'我的订单','32ee07e35de6a731007a37331df27a97',0,0,0,'[\"order/list\"]',''),
	(18,4,' 我的预约','e9529df989a692713075f365b896529c',0,0,0,'[\"/appointment/mine\"]',''),
	(19,4,'收货地址','b89b90e54d03c255d37147a105dfdfc6',0,0,0,'[\"/address/list\"]',''),
	(20,5,'第一张','bfedf634f944cd6a98ae6422a83dc0dd',2,0,0,'#','{\r\n    \"image\":\"/images/banner/index.jpg\"\r\n}'),
	(21,6,'会员卡','card',0,0,0,'#','{\r\n    \"icon\":\"/images/pay/card.png\"\r\n}'),
	(22,6,'支付宝','alipay',0,0,0,'#','{\r\n    \"icon\":\"/images/pay/alipay.png\"\r\n}'),
	(23,6,'微信支付','wechat-pay',0,0,0,'#','{\r\n    \"icon\":\"/images/pay/wechat.png\"\r\n}'),
	(24,7,'妇科','ff8119e271c381c103b7f225504a1f08',0,0,0,'{\"0\":\"/appointment/ask\",\"department\":\"妇科\"}',''),
	(25,7,'儿科','93903e3663a2806225bf2a42d88fdcd2',0,0,0,'{\"0\":\"/appointment/ask\",\"department\":\"儿科\"}',''),
	(26,7,'男科','f22dbc3e1213322aace42157ddd16007',0,0,0,'{\"0\":\"/appointment/ask\",\"department\":\"男科\"}',''),
	(27,7,'女科','b3eb2741c9804711d188e8f1ec01906c',0,0,0,'{\"0\":\"/appointment/ask\",\"department\":\"女科\"}',''),
	(28,7,'老人','d423053614b1198c6c74af791b42aa3b',0,0,0,'{\"0\":\"/appointment/ask\",\"department\":\"老人\"}',''),
	(29,7,'小孩','5d8d33bab6589d005afc80fd68a75bc3',0,0,0,'{\"0\":\"/appointment/ask\",\"department\":\"小孩\"}',''),
	(30,4,'会员卡','dc194c28c764a390e63bb3191fb73b10',0,0,0,'[\"/card/mine\"]','');

/*!40000 ALTER TABLE `link_group_item` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table manage_user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `manage_user`;

CREATE TABLE `manage_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `role` int(11) NOT NULL DEFAULT '0',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `manage_user` WRITE;
/*!40000 ALTER TABLE `manage_user` DISABLE KEYS */;

INSERT INTO `manage_user` (`id`, `user_id`, `role`, `created_at`, `updated_at`)
VALUES
	(1,1,0,1513085852,1513085852);

/*!40000 ALTER TABLE `manage_user` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table member_card
# ------------------------------------------------------------

DROP TABLE IF EXISTS `member_card`;

CREATE TABLE `member_card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `pay_discount` int(11) NOT NULL,
  `description` text,
  `time_long` int(11) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL DEFAULT '0',
  `options` varchar(255) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `member_card` WRITE;
/*!40000 ALTER TABLE `member_card` DISABLE KEYS */;

INSERT INTO `member_card` (`id`, `name`, `price`, `discount`, `pay_discount`, `description`, `time_long`, `order`, `options`, `created_at`, `updated_at`)
VALUES
	(1,'尊赏家庭卡',1500000,100,70,'尊赏家庭卡',60,1,'{\r\n    \"image\":\"/images/card-jiating-1.png\"\r\n}',1515163987,1518099070),
	(2,'尊赏凤凰卡',900000,1000,75,'尊赏凤凰卡',60,2,'{\r\n    \"image\":\"/images/card-fenghuang-2.png\"\r\n}',1515164017,1518099085),
	(3,'金凤凰卡',600000,100,80,'金凤凰卡',60,3,'{\r\n    \"image\":\"/images/card-fenghuang-3.png\"\r\n}',1518098868,1518099097),
	(4,'凤凰卡',300000,100,90,'凤凰卡',60,4,'{\r\n    \"image\":\"/images/card-fenghuang-4.png\"\r\n}',1518098990,1518099101);

/*!40000 ALTER TABLE `member_card` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table member_card_pay_log
# ------------------------------------------------------------

DROP TABLE IF EXISTS `member_card_pay_log`;

CREATE TABLE `member_card_pay_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `pay_price` double NOT NULL,
  `card_price` double NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `member_card_pay_log` WRITE;
/*!40000 ALTER TABLE `member_card_pay_log` DISABLE KEYS */;

INSERT INTO `member_card_pay_log` (`id`, `card_id`, `order_id`, `pay_price`, `card_price`, `created_at`)
VALUES
	(1,2,19,4750,4410.52,1515688063),
	(2,2,19,4750,4492.5,1515688294);

/*!40000 ALTER TABLE `member_card_pay_log` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table member_own_card
# ------------------------------------------------------------

DROP TABLE IF EXISTS `member_own_card`;

CREATE TABLE `member_own_card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `original_money` double NOT NULL,
  `remain_money` double NOT NULL,
  `discount` int(11) NOT NULL,
  `expire_at` int(11) DEFAULT NULL,
  `is_enable` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `member_own_card` WRITE;
/*!40000 ALTER TABLE `member_own_card` DISABLE KEYS */;

INSERT INTO `member_own_card` (`id`, `card_id`, `user_id`, `original_money`, `remain_money`, `discount`, `expire_at`, `is_enable`, `created_at`)
VALUES
	(2,2,1,1000,1118.98,95,21101,1,123123);

/*!40000 ALTER TABLE `member_own_card` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table migration
# ------------------------------------------------------------

DROP TABLE IF EXISTS `migration`;

CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `migration` WRITE;
/*!40000 ALTER TABLE `migration` DISABLE KEYS */;

INSERT INTO `migration` (`version`, `apply_time`)
VALUES
	('m000000_000000_base',1513000924),
	('m130524_201442_user',1513085851),
	('m170503_162121_category',1513085851),
	('m171209_085839_link_group',1513085851),
	('m171209_085931_link_group_item',1513085851),
	('m171209_090206_article',1513085851),
	('m171209_090443_article_content',1513085851),
	('m171209_090541_article_mount_data',1513085851),
	('m171209_090655_doctor',1513085851),
	('m171209_091140_doctor_service_time',1513085851),
	('m171209_091426_doctor_level',1513085851),
	('m171209_092622_doctor_appointment',1513085851),
	('m171209_092947_doctor_appointment_patient_info',1513085851),
	('m171209_093225_doctor_appointment_track',1513085851),
	('m171209_093610_website_config',1513085851),
	('m171209_094000_website_config_group',1513085851),
	('m171211_072421_manage_user',1513085851),
	('m171211_072422_manage_user_init',1513085852),
	('m171211_144209_alter_website_config',1513085852),
	('m171212_093335_init_webconfig_data',1513090390),
	('m171214_023735_auth_wechat',1513693790),
	('m171219_032200_alter_doctor_service_time',1513693870),
	('m171220_055842_alter_article',1514299113),
	('m171220_060009_article_type',1514299113),
	('m171220_060019_article_type_field',1514299113),
	('m171221_040807_alter_website_config_item',1514299114),
	('m171221_060140_code_block',1514299114),
	('m171226_144910_doctor_department',1514299875),
	('m171226_145010_department',1514299875),
	('m171226_151508_doctor_tag',1514301349),
	('m171226_153106_patient_feedback',1514382258),
	('m171227_032441_sms_history',1514382258),
	('m171227_101141_order',1514382258),
	('m171227_103350_order_mont_data',1514382258),
	('m171227_151505_my_patient',1514388258),
	('m171230_093255_patient_ask',1514645041),
	('m180101_072158_alter_my_patient',1514792138),
	('m180105_020922_member_card',1515161140),
	('m180105_021612_member_own_card',1515329918),
	('m180107_022504_alter_member_own_card',1515329918),
	('m180107_023133_alter_order',1515329918),
	('m180107_023822_member_card_pay_log',1515329918),
	('m180107_073146_doctor_service_time_range',1515329918),
	('m180107_093206_alter_doctor',1515329918),
	('m180107_133438_alter_my_patient',1515332139),
	('m180108_125932_alter_patient_ask',1515416452),
	('m180110_134632_alter_member_own_card',1515592120),
	('m180110_152654_user_coin',1515598158),
	('m180110_152745_user_coin_history',1515598158),
	('m180110_155318_promotion_card',1515599746),
	('m180204_140147_alter_doctor_patient',1517753108),
	('m180204_143358_card_password',1517754949),
	('m180204_144729_address',1517755864),
	('m180206_144027_alter_doctor',1517928080);

/*!40000 ALTER TABLE `migration` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table my_patient
# ------------------------------------------------------------

DROP TABLE IF EXISTS `my_patient`;

CREATE TABLE `my_patient` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `sex` smallint(2) NOT NULL,
  `birth` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `identify` varchar(255) NOT NULL,
  `relation` int(11) NOT NULL DEFAULT '0',
  `height` int(11) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `is_self` smallint(2) NOT NULL DEFAULT '0',
  `default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `my_patient` WRITE;
/*!40000 ALTER TABLE `my_patient` DISABLE KEYS */;

INSERT INTO `my_patient` (`id`, `user_id`, `name`, `sex`, `birth`, `phone`, `identify`, `relation`, `height`, `weight`, `is_self`, `default`)
VALUES
	(1,1,'12123',0,'2018-1-1','13212321234','123132123212341234',0,0,0,0,1);

/*!40000 ALTER TABLE `my_patient` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table order
# ------------------------------------------------------------

DROP TABLE IF EXISTS `order`;

CREATE TABLE `order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `out_trade_id` varchar(255) NOT NULL,
  `channel` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `complete_at` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;

INSERT INTO `order` (`id`, `user_id`, `order_id`, `out_trade_id`, `channel`, `name`, `price`, `status`, `complete_at`, `created_at`, `updated_at`)
VALUES
	(4,0,'201712311002545a48ee0e1be1100920','','wechatpay','2018 预约  杨豪豪 医生 妇科 会诊',1,0,0,1514728974,1514728974),
	(5,0,'201712311004515a48ee830525600157','','wechatpay','2018-1-1 预约  杨豪豪 医生 妇科 会诊',12800,0,0,1514729091,1514729091),
	(6,0,'201712311005055a48ee91ea9bf00629','','wechatpay','2018-1-1 预约  杨豪豪 医生 妇科 会诊',12800,0,0,1514729105,1514729105),
	(7,1,'201712311005395a48eeb37692700614','4200000017201712315427547480','wechatpay','2018-1-1 预约  杨豪豪 医生 妇科 会诊',1,1,1514733455,1514729139,1514733455),
	(8,0,'','','','',0,0,0,0,0),
	(9,1,'201801080949435a5376f7d1ce600703','','unknown','咨询  杨豪豪 杨小九的病情',2000,0,0,1515419383,1515419383),
	(10,1,'201801081010295a537bd50bda400557','','unknown','咨询  杨豪豪 杨小九的病情',2000,0,0,1515420629,1515420629),
	(11,1,'201801081010515a537beb5d30d00375','','unknown','咨询  杨豪豪 杨小九的病情',2000,0,0,1515420651,1515420651),
	(12,1,'201801081012125a537c3c536f600894','','unknown','咨询  杨豪豪 杨小九的病情',2000,3,0,1515420732,1515599231),
	(17,1,'201801101224465a54ecce40cdf00894','','unknown','2018-1-10  杨豪豪 医生  会诊',12800,0,0,1515515086,1515515086),
	(18,1,'201801101031015a5623a57035500806','','unknown','会员卡 金卡 购买',475000,3,0,1515594661,1515599181),
	(19,1,'201801101032255a5623f98831b00384','','unknown','会员卡 金卡 购买',475000,0,0,1515594745,1515594745),
	(20,1,'201801140137315a5aec9bcfece00110','','unknown','咨询  杨豪豪 asdf的病情',2000,0,0,1515908251,1515908251),
	(21,1,'201801140341095a5b0995295dd00429','','unknown','会员卡 银卡 购买',247500,0,0,1515915669,1515915669),
	(22,1,'201801140519055a5b208906cda00688','','unknown','2018-1-16  杨豪豪 医生  会诊',12800,0,0,1515921545,1515921545),
	(23,3,'201801140721195a5b3d2fba99700850','','unknown','咨询  杨豪豪 杨豪的病情',2000,0,0,1515928879,1515928879),
	(24,3,'201801140725165a5b3e1c5d24e00329','','unknown','2018-1-15  杨豪豪 医生  会诊',12800,0,0,1515929116,1515929116),
	(25,3,'201801140736245a5b40b8bc7ed00496','4200000068201801143974786132','wechat-pay','咨询  杨豪豪 哈哈哈督促的病情',1,1,1515929964,1515929784,1515929964),
	(26,3,'201801140847235a5b515bd38b900967','','unknown','咨询  杨豪豪 仿佛我的病情',2000,0,0,1515934043,1515934043),
	(27,1,'201802070915065a7afbda2664c00009','','unknown','会员卡 金卡 购买',475000,0,0,1518009306,1518009306),
	(32,1,'201802071013555a7b09a349bb900947','','wechat-pay','2018-2-7  杨豪豪 医生 消化道 会诊',12800,0,0,1518012835,1518012835),
	(33,1,'201802081014525a7c5b5ce83e700806','','unknown','会员卡 尊赏家庭卡 购买',1500000,0,0,1518099292,1518099292),
	(34,1,'201803200902375ab1066d23ea000821','','card','2018-3-21  杨豪豪 医生 妇科 会诊',12800,1,1515929964,1521550957,1521550957),
	(35,1,'201803200911565ab1089cd24de00130','','unknown','2018-3-21  杨豪豪 医生 妇科 会诊',12800,2,0,1521551516,1521554328),
	(36,1,'201803200921215ab10ad10035b00027','','unknown','尊赏家庭卡 会员卡充值',1002389400,0,0,1521552081,1521552081),
	(37,1,'201803200922295ab10b154439300412','','unknown','尊赏家庭卡 会员卡充值',12300,0,0,1521552149,1521552149),
	(38,1,'201803241129515ab5c62fd803800298','','unknown','咨询  杨豪豪 asdf的病情',2000,0,0,1521862191,1521862191),
	(39,1,'201803241142405ab5c930869ca00139','','unknown','尊赏凤凰卡 会员卡充值',12312300,0,0,1521862960,1521862960),
	(40,1,'201803241143145ab5c952316f300538','','unknown','会员卡 尊赏家庭卡 购买',1500000,0,0,1521862994,1521862994),
	(41,1,'201803240725555ab635c33a67100459','','unknown','咨询  杨豪豪 的病情',2000,0,0,1521890755,1521890755),
	(42,1,'201803240728025ab6364269fb800775','','unknown','咨询  杨豪豪 12123的病情',2000,0,0,1521890882,1521890882);

/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table order_mont_data
# ------------------------------------------------------------

DROP TABLE IF EXISTS `order_mont_data`;

CREATE TABLE `order_mont_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `order_mont_data` WRITE;
/*!40000 ALTER TABLE `order_mont_data` DISABLE KEYS */;

INSERT INTO `order_mont_data` (`id`, `order_id`, `name`, `content`)
VALUES
	(1,'4','appointment_id','3'),
	(2,'5','appointment_id','4'),
	(3,'6','appointment_id','5'),
	(4,'7','appointment_id','6'),
	(5,'9','callback','{\"callback\":[\"common\\\\models\\\\PatientAsk\",\"callbackPaySuccess\"],\"params\":[10]}'),
	(6,'10','callback','{\"callback\":[\"common\\\\models\\\\PatientAsk\",\"callbackPaySuccess\"],\"params\":[11]}'),
	(7,'11','callback','{\"callback\":[\"common\\\\models\\\\PatientAsk\",\"callbackPaySuccess\"],\"params\":[12]}'),
	(8,'12','patient_ask','13'),
	(9,'12','callback','{\"callback\":[\"common\\\\models\\\\PatientAsk\",\"callbackPaySuccess\"],\"params\":[13]}'),
	(10,'17','doctor_appointment','11'),
	(11,'17','callback','{\"callback\":[\"common\\\\models\\\\DoctorAppointment\",\"callbackPaySuccess\"],\"params\":[11]}'),
	(12,'18','enableCard','0'),
	(13,'18','enableCoin','0'),
	(14,'18','callback','{\"callback\":[\"common\\\\models\\\\MemberOwnCard\",\"callbackPaySuccess\"],\"params\":[1]}'),
	(15,'18','member_card','1'),
	(16,'19','enableCard','0'),
	(17,'19','enableCoin','0'),
	(18,'19','callback','{\"callback\":[\"common\\\\models\\\\MemberOwnCard\",\"callbackPaySuccess\"],\"params\":[1]}'),
	(19,'19','member_card','1'),
	(20,'19','enableCode','0'),
	(21,'19','minus','{\"coin\":1.98,\"code\":100,\"discount\":237.5}'),
	(22,'19','minus','{\"coin\":20,\"code\":0,\"discount\":237.5}'),
	(23,'20','patient_ask','14'),
	(24,'20','callback','{\"callback\":[\"common\\\\models\\\\PatientAsk\",\"callbackPaySuccess\"],\"params\":[14]}'),
	(25,'21','enableCard','0'),
	(26,'21','enableCoin','0'),
	(27,'21','enableCode','0'),
	(28,'21','callback','{\"callback\":[\"common\\\\models\\\\MemberOwnCard\",\"callbackPaySuccess\"],\"params\":[2]}'),
	(29,'21','member_card','2'),
	(30,'22','doctor_appointment','12'),
	(31,'22','callback','{\"callback\":[\"common\\\\models\\\\DoctorAppointment\",\"callbackPaySuccess\"],\"params\":[12]}'),
	(32,'23','patient_ask','15'),
	(33,'23','callback','{\"callback\":[\"common\\\\models\\\\PatientAsk\",\"callbackPaySuccess\"],\"params\":[15]}'),
	(35,'24','doctor_appointment','13'),
	(36,'24','callback','{\"callback\":[\"common\\\\models\\\\DoctorAppointment\",\"callbackPaySuccess\"],\"params\":[13]}'),
	(39,'25','patient_ask','16'),
	(40,'25','callback','{\"callback\":[\"common\\\\models\\\\PatientAsk\",\"callbackPaySuccess\"],\"params\":[16]}'),
	(45,'26','patient_ask','17'),
	(46,'26','callback','{\"callback\":[\"common\\\\models\\\\PatientAsk\",\"callbackPaySuccess\"],\"params\":[17]}'),
	(47,'27','enableCard','0'),
	(48,'27','enableCoin','0'),
	(49,'27','enableCode','0'),
	(50,'27','callback','{\"callback\":[\"common\\\\models\\\\MemberOwnCard\",\"callbackPaySuccess\"],\"params\":[1]}'),
	(51,'27','member_card','1'),
	(52,'32','department','4'),
	(53,'32','doctor_appointment','18'),
	(54,'32','callback','{\"callback\":[\"common\\\\models\\\\DoctorAppointment\",\"callbackPaySuccess\"],\"params\":[18]}'),
	(55,'33','enableCard','0'),
	(56,'33','enableCoin','0'),
	(57,'33','enableCode','0'),
	(58,'33','callback','{\"callback\":[\"common\\\\models\\\\MemberOwnCard\",\"callbackPaySuccess\"],\"params\":[1]}'),
	(59,'33','member_card','1'),
	(60,'34','department','1'),
	(61,'34','doctor_appointment','19'),
	(62,'34','callback','{\"callback\":[\"common\\\\models\\\\DoctorAppointment\",\"callbackPaySuccess\"],\"params\":[19]}'),
	(63,'35','department','1'),
	(64,'35','doctor_appointment','20'),
	(65,'35','callback','{\"callback\":[\"common\\\\models\\\\DoctorAppointment\",\"callbackPaySuccess\"],\"params\":[20]}'),
	(66,'36','enableCard','0'),
	(67,'36','enableCoin','0'),
	(68,'36','enableCode','0'),
	(69,'36','callback','{\"callback\":[\"common\\\\models\\\\MemberOwnCard\",\"callbackChargeSuccess\"],\"params\":[2]}'),
	(70,'36','member_own_card','2'),
	(71,'37','enableCard','0'),
	(72,'37','enableCoin','0'),
	(73,'37','enableCode','0'),
	(74,'37','callback','{\"callback\":[\"common\\\\models\\\\MemberOwnCard\",\"callbackChargeSuccess\"],\"params\":[2]}'),
	(75,'37','member_own_card','2'),
	(76,'38','patient_ask','18'),
	(77,'38','callback','{\"callback\":[\"common\\\\models\\\\PatientAsk\",\"callbackPaySuccess\"],\"params\":[18]}'),
	(78,'39','enableCard','0'),
	(79,'39','enableCoin','0'),
	(80,'39','enableCode','0'),
	(81,'39','callback','{\"callback\":[\"common\\\\models\\\\MemberOwnCard\",\"callbackChargeSuccess\"],\"params\":[2]}'),
	(82,'39','member_own_card','2'),
	(83,'40','enableCard','0'),
	(84,'40','enableCoin','0'),
	(85,'40','enableCode','0'),
	(86,'40','callback','{\"callback\":[\"common\\\\models\\\\MemberOwnCard\",\"callbackPaySuccess\"],\"params\":[1]}'),
	(87,'40','member_card','1'),
	(88,'41','patient_ask','19'),
	(89,'41','callback','{\"callback\":[\"common\\\\models\\\\PatientAsk\",\"callbackPaySuccess\"],\"params\":[19]}'),
	(90,'42','patient_ask','20'),
	(91,'42','callback','{\"callback\":[\"common\\\\models\\\\PatientAsk\",\"callbackPaySuccess\"],\"params\":[20]}');

/*!40000 ALTER TABLE `order_mont_data` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table patient_ask
# ------------------------------------------------------------

DROP TABLE IF EXISTS `patient_ask`;

CREATE TABLE `patient_ask` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `images` text,
  `reply` text,
  `reply_at` int(11) DEFAULT NULL,
  `pay_status` int(11) NOT NULL DEFAULT '0',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `patient_ask` WRITE;
/*!40000 ALTER TABLE `patient_ask` DISABLE KEYS */;

INSERT INTO `patient_ask` (`id`, `user_id`, `doctor_id`, `patient_id`, `description`, `images`, `reply`, `reply_at`, `pay_status`, `created_at`, `updated_at`)
VALUES
	(1,1,1,1,'asdfasdf','',NULL,NULL,0,1514645419,1514645419),
	(2,1,2,1,'asdfasdfasdfasdf','','我去你大爷的！',1514648517,0,1514646917,1514648517),
	(3,1,2,1,'asdfasdfasdf','/upload/2017/12/30/1efa7843d0341f32b757c824986f1508.png,/upload/2017/12/30/098f6bcd4621d373cade4e832627b4f6.jpg','asdfasdfasdfaf',1514647522,0,1514647433,1514647522),
	(10,1,1,1,'asdfasdfasdfasdfasdf','',NULL,NULL,0,1515419380,1515419380),
	(11,1,1,1,'asdfasdfasdfasdfasdfasdf','',NULL,NULL,0,1515420629,1515420629),
	(12,1,1,1,'asdfasdfasdfasdfasdfasdf','',NULL,NULL,0,1515420651,1515420651),
	(13,1,1,1,'asdfasdfasdfasdfasdfasdf','',NULL,NULL,0,1515420732,1515420732),
	(14,1,1,2,'asdfasdfasdf','',NULL,NULL,0,1515908251,1515908251),
	(15,3,1,6,'我来问一个问题吧','',NULL,NULL,0,1515928879,1515928879),
	(16,3,1,10,'刚回家就好','','不可以这么回复我哦！',1515933718,2,1515929784,1515933718),
	(17,3,1,9,'asdasdasd','',NULL,NULL,0,1515934043,1515934043),
	(18,1,1,2,'asdfasdf','',NULL,NULL,0,1521862191,1521862191),
	(19,1,1,2,'asfasdfasdf','',NULL,NULL,0,1521890755,1521890755),
	(20,1,1,1,'123123123','',NULL,NULL,0,1521890882,1521890882);

/*!40000 ALTER TABLE `patient_ask` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table patient_feedback
# ------------------------------------------------------------

DROP TABLE IF EXISTS `patient_feedback`;

CREATE TABLE `patient_feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doctor_id` int(11) NOT NULL,
  `appointment_id` int(11) NOT NULL,
  `mark` int(11) NOT NULL,
  `content` varchar(255) NOT NULL DEFAULT '',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `patient_feedback` WRITE;
/*!40000 ALTER TABLE `patient_feedback` DISABLE KEYS */;

INSERT INTO `patient_feedback` (`id`, `doctor_id`, `appointment_id`, `mark`, `content`, `created_at`, `updated_at`)
VALUES
	(3,1,11,3,'khkjh',1514807185,1514807185),
	(4,1,3,4,'asfasdfasdfasdfasdf',1521465846,1521465846);

/*!40000 ALTER TABLE `patient_feedback` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table promotion_card
# ------------------------------------------------------------

DROP TABLE IF EXISTS `promotion_card`;

CREATE TABLE `promotion_card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `card_number` varchar(255) NOT NULL,
  `card_worth` int(11) NOT NULL,
  `batch_code` varchar(255) NOT NULL,
  `active_at` int(11) NOT NULL DEFAULT '0',
  `created_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `promotion_card` WRITE;
/*!40000 ALTER TABLE `promotion_card` DISABLE KEYS */;

INSERT INTO `promotion_card` (`id`, `user_id`, `card_number`, `card_worth`, `batch_code`, `active_at`, `created_at`)
VALUES
	(1,0,'20180111-003533-IEK-826112',12,'123',0,1515602133),
	(2,0,'20180111-003533-SN6-458396',12,'123',0,1515602133),
	(3,0,'20180111-004056-W_N-97',100,'123a',0,1515602456),
	(4,0,'20180111-004056-CBC-23',100,'123a',0,1515602456),
	(5,0,'20180111-004056-M38-96',100,'123a',0,1515602456),
	(6,0,'20180111-004056-VOU-30',100,'123a',0,1515602456),
	(7,0,'20180111-004056-IHQ-95',100,'123a',0,1515602456),
	(8,0,'20180111-004056-MJW-48',100,'123a',0,1515602456),
	(9,0,'20180111-004056-QTZ-18',100,'123a',0,1515602456),
	(10,0,'20180111-004056-5V5-99',100,'123a',0,1515602456),
	(11,0,'20180111-004056-5R9-77',100,'123a',0,1515602456),
	(12,0,'20180111-004056-6EP-27',100,'123a',0,1515602456),
	(13,0,'20180111-004116-3C8-13',100,'123a',0,1515602476),
	(14,0,'20180111-004116-TF2-18',100,'123a',0,1515602476),
	(15,0,'20180111-004116-VCS-72',100,'123a',0,1515602476),
	(16,0,'20180111-004116-1PE-73',100,'123a',0,1515602476),
	(17,0,'20180111-004116-TNG-19',100,'123a',0,1515602476),
	(18,0,'20180111-004116-XGJ-83',100,'123a',0,1515602476),
	(19,0,'20180111-004116-NYV-27',100,'123a',0,1515602476),
	(20,0,'20180111-004116-DSR-18',100,'123a',0,1515602476),
	(21,1,'20180111-004116-DAV-38',100,'123a',1515688041,1515602476),
	(22,0,'20180111-004116-9FR-16',100,'123a',0,1515602476);

/*!40000 ALTER TABLE `promotion_card` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table sms_history
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sms_history`;

CREATE TABLE `sms_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `success` tinyint(1) NOT NULL DEFAULT '1',
  `data` varchar(255) NOT NULL,
  `created_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `nickname` varchar(255) NOT NULL DEFAULT '',
  `auth_key` varchar(32) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `password_reset_token` varchar(255) DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `head_image` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `password_reset_token` (`password_reset_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;

INSERT INTO `user` (`id`, `phone`, `email`, `nickname`, `auth_key`, `password_hash`, `password_reset_token`, `status`, `created_at`, `updated_at`, `head_image`)
VALUES
	(1,'186010137341','rogeecn@qq.com','Rogee','','$2y$13$S6mCK9bVtA2PXch4JsspfeFZE/rBPN1Wjfjro9qbhMmjuVUeMVnK2',NULL,0,1513085852,1513085852,'http://wx.qlogo.cn/mmopen/vi_32/PiajxSqBRaELicm764IgVkASNztuGALTxHFluVrzkicO3rwv2QHS67dWkZC7aPuJMKkz1voElWeWmdibNLrJA6qCvg/0'),
	(2,'123123123123','','','KBy_jwYbcaR-ABz-w79t5HohGCNzMxgk','$2y$13$NQNYbf24dWmApfgoqTk2se0hUg8FP/cHRIaq7VcUkB1Vfyo6JxPee',NULL,0,1514777935,1514777935,''),
	(3,'18601013734','u-20180105223210@wechat.auth','Rogee','r0dFTnWdZ5MwZWLZlhNI_nLSord1SPmT','$2y$13$.oEJhdDBoecFeWkXD63TJerUsND54H7lwC1ouYhW04X9EFe3FgKse',NULL,0,1515162730,1515162730,'http://wx.qlogo.cn/mmopen/vi_32/PiajxSqBRaELicm764IgVkASNztuGALTxHFluVrzkicO3rwv2QHS67dWkZC7aPuJMKkz1voElWeWmdibNLrJA6qCvg/0');

/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table user_coin
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user_coin`;

CREATE TABLE `user_coin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `coin` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `user_coin` WRITE;
/*!40000 ALTER TABLE `user_coin` DISABLE KEYS */;

INSERT INTO `user_coin` (`id`, `user_id`, `coin`)
VALUES
	(1,1,200);

/*!40000 ALTER TABLE `user_coin` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table user_coin_history
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user_coin_history`;

CREATE TABLE `user_coin_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `coin` int(11) NOT NULL,
  `action` varchar(1) NOT NULL,
  `desc` varchar(255) NOT NULL,
  `created_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `user_coin_history` WRITE;
/*!40000 ALTER TABLE `user_coin_history` DISABLE KEYS */;

INSERT INTO `user_coin_history` (`id`, `user_id`, `coin`, `action`, `desc`, `created_at`)
VALUES
	(1,1,1000,'-','订单消费抵扣',1515688275),
	(2,1,100,'+','评论获取积分',1521465846);

/*!40000 ALTER TABLE `user_coin_history` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table website_config
# ------------------------------------------------------------

DROP TABLE IF EXISTS `website_config`;

CREATE TABLE `website_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` text,
  `hint` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(255) NOT NULL DEFAULT 'textInput',
  `const_data` text,
  `group_id` int(11) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL DEFAULT '0',
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `website_config` WRITE;
/*!40000 ALTER TABLE `website_config` DISABLE KEYS */;

INSERT INTO `website_config` (`id`, `key`, `name`, `value`, `hint`, `type`, `const_data`, `group_id`, `order`, `created_at`)
VALUES
	(1,'site.logo','网站LOGO','@webroot/images/logo.png','','string','',1,0,1521466579),
	(2,'site.domain','网站访问地址','http://mp.711xd.com','','string',NULL,1,0,1521466579),
	(3,'site.name','网站名称','汉典中医','','string',NULL,1,0,1521466579),
	(4,'site.slogan','网站副标题','Beautiful & Easy!','','string',NULL,1,0,1521466579),
	(5,'site.keyword','网站关键字','YummyHospital,医院CMS','','string',NULL,1,0,1521466579),
	(6,'site.description','网站描述','一个好用的医院CMS管理系统','','string',NULL,1,0,1521466579),
	(7,'site.regulator.icp','ICP备案号','','','string',NULL,1,0,1521466579),
	(8,'site.regulator.police','公安备案号','','','string',NULL,1,0,1521466579),
	(9,'site.statistic.baidu','百度统计ID','','只写ID即可','string',NULL,1,0,1521466579),
	(10,'site.statistic.other','其它统计代码','','JS代码，带Script标签','text',NULL,1,0,1521466579),
	(11,'split.hYo5tL1dhiuvQ-ledBJk1OvA1_EkKz35','阿里云配置','','','split',NULL,2,0,1521466579),
	(12,'site.aliyun.access_key_id','Access Key ID','LTAImYoo3TAwB8zv','','string',NULL,2,0,1521466579),
	(13,'site.aliyun.access_key_secret','Access Key Secret','MOajOX1iPOmyj3nGtvP9vctNyqX5Lh','','string',NULL,2,0,1521466579),
	(14,'split.P_nlWOpIbe8iE3-733_ZlDdVmiwwA0tj','阿里云短信平台','','','split',NULL,2,0,1521466579),
	(15,'site.aliyun.sms_template_id','短信模板ID','SMS_119082144','请填写审核通过后的短信模板ID','string',NULL,2,0,1521466579),
	(16,'email.smtp.host','SMTP 主机','smtpdm.aliyun.com','','string',NULL,3,0,1521466579),
	(17,'email.smtp.port','SMTP 端口','80','','string',NULL,3,0,1521466579),
	(18,'email.smtp.nickname','SMTP 发信人名称','爱泡云','','string',NULL,3,0,1521466579),
	(19,'email.smtp.password','SMTP 密码','','','string',NULL,3,0,1521466579),
	(20,'split.WgAbiCGplWnskZPxS3uhaZtDPZ3n4Yij','文件缓存配置','','','split','',4,0,1521466579),
	(21,'cache.model','缓存模式','file','','single','{\"file\":\"\\u6587\\u4ef6\\u7f13\\u5b58\",\"redis\":\"Redis\",\"memcache\":\"Memcache\"}',4,0,1521466579),
	(22,'split.MhhOwd43pLXz_J0pEeboGpHxazy6SIeB','Redis配置','','','split',NULL,4,0,1521466579),
	(23,'cache.file.path','缓存路径','@application/runtime/cache','','string',NULL,4,0,1521466579),
	(24,'cache.redis.port','端口','','','string',NULL,4,0,1521466579),
	(25,'cache.redis.host','主机地址','','','string',NULL,4,0,1521466579),
	(26,'split.NVKh8QlHeQUEvbDtZNSqv3OWfwxRYlV6','Memcache设置','','','split',NULL,4,0,1521466579),
	(27,'cache.redis.auth','密码','','','string',NULL,4,0,1521466579),
	(28,'cache.memcache.port','端口','','','string',NULL,4,0,1521466579),
	(29,'cache.memcache.host','主机地址','','','string',NULL,4,0,1521466579),
	(30,'split.QkL6afEdYUVkP518cC7p76vaaiBN6CMO','本地存储配置','','','split',NULL,5,0,1521466579),
	(31,'storage.mode','文件存储模式','file','','single','{\"file\":\"\\u672c\\u5730\\u5b58\\u50a8\",\"aliyun_oss\":\"\\u963f\\u91cc\\u4e91OSS\"}',5,0,1521466579),
	(32,'split.DQxtgz29B2mEyQEm4m_U-hKwbqMdZl7I','阿里云OSS配置','','','split',NULL,5,0,1521466579),
	(33,'storage.file.path','本地存储路径','@webroot/upload','','string',NULL,5,0,1521466579),
	(34,'split.h9hx6YdHscIRpGgvdTMRkZGgo3LFqwwF','阿里云OSS配置','','','split',NULL,5,0,1521466579),
	(35,'storage.aliyun_oss.domain','访问域名','http://oss.ipaoyun.com','访问域名','string',NULL,5,0,1521466579),
	(36,'storage.aliyun_oss.bucket','Bucket','','','string',NULL,5,0,1521466579),
	(37,'storage.aliyun_oss.is_internal','内网模式','1','','single','[\"\\u5426\",\"\\u662f\"]',5,0,1521466579),
	(38,'split.p51byal1y7njNKHqunUIpp-xbop7mcEx','支付宝','','','split',NULL,6,0,1521466579),
	(39,'payment.channel','支付通道','alipay,wechatpay','按Ctrl可进行多选','multiple','{\"alipay\":\"\\u652f\\u4ed8\\u5b9d\",\"wechatpay\":\"\\u5fae\\u4fe1\\u652f\\u4ed8\"}',6,0,1521466579),
	(40,'split.YhfWMfYD5aOGMxL4Aitf7aMRIRK8aDWV','支付宝','','','split',NULL,6,0,1521466579),
	(41,'payment.alipay.sign_type','加密类型','RSA','','single','{\"RSA\":\"RSA\",\"RSA2\":\"RSA2\"}',6,0,1521466579),
	(42,'payment.alipay.cert_public','公钥','@application/certs/alipay/alipay_public_key.pem','','string',NULL,6,0,1521466579),
	(43,'payment.alipay.cert_private','私钥','@application/certs/alipay/rsa_private_key_pkcs8.pem','','string',NULL,6,0,1521466579),
	(44,'split.B5uMlSAH3WLnKFwluEZVuNp_SuPELLHB','微信支付','','','split',NULL,6,0,1521466579),
	(45,'payment.alipay.callback','回调地址','http://xxx.com/callback','http://xxx.com/callback','string',NULL,6,0,1521466580),
	(46,'split.vBnh-gEdnIkROClmXY8hSVUg3yyzO-m-','微信支付','','','split',NULL,6,0,1521466580),
	(47,'payment.wechatpay.app_id','AppID','wxdda77b2287d27469','绑定支付的APPID（必须配置，开户邮件中可查看）','string',NULL,6,0,1521466580),
	(48,'payment.wechatpay.app_secret','公众号Secret','776a45e0a053503f56b7cd79423672dc',' 微信公众平台生成','string','',6,0,1521466580),
	(49,'payment.wechatpay.mch_id','商户号','1495401442','必须配置，开户邮件中可查看','string',NULL,6,0,1521466580),
	(50,'payment.wechatpay.key','支付证书KEY','@common/certs/wechat/apiclient_key.pem','必须配置，登录商户平台自行设置','string','',6,0,1521466580),
	(51,'payment.wechatpay.cert','支付证书','@common/certs/wechat/apiclient_cert.pem','仅退款、撤销订单时需要，可登录商户平台下载','string','',6,0,1521466580),
	(52,'payment.wechatpay.callback','回调地址','http://mp.711xd.com/callback/wechat','异步回调通知 http://xxx.com/callback','string',NULL,6,0,1521466580),
	(53,'wechat.app_id','AppID','wxdda77b2287d27469','','string',NULL,7,0,1521466580),
	(54,'wechat.app_secret','AppSecret','776a45e0a053503f56b7cd79423672dc','','string',NULL,7,0,1521466580),
	(55,'wechat.token','Token','mp_711_xd_com_wechat','','string',NULL,7,0,1521466580),
	(56,'payment.wechatpay.api_key','API密钥','7fe997c8d3b2dd1a1ae5e76b0acc6084','','string','',6,0,1521466580),
	(57,'site.hospital.location','医院地址','朝阳区石佛营东里133号','医院地址','string','',2,0,1521466580),
	(58,'global.enable-ace-vim','代码编辑器VIM模式','1','是否开启VIM模式','single','[\"否\",\"是\"]',2,0,1521466580),
	(59,'global.coin-rate','积分兑换比率','0.02','如100积分换1元则为 1÷100 = 0.01','string','',2,0,1521466580),
	(60,'global.feedback-gain-coin','评论获取积分数量','100','','string','',2,0,1521466580);

/*!40000 ALTER TABLE `website_config` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table website_config_group
# ------------------------------------------------------------

DROP TABLE IF EXISTS `website_config_group`;

CREATE TABLE `website_config_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `website_config_group` WRITE;
/*!40000 ALTER TABLE `website_config_group` DISABLE KEYS */;

INSERT INTO `website_config_group` (`id`, `name`, `order`, `created_at`)
VALUES
	(1,'网站',0,1521466579),
	(2,'全局',0,1521466579),
	(3,'邮件',0,1521466579),
	(4,'缓存',0,1521466579),
	(5,'存储',0,1521466579),
	(6,'支付',0,1521466579),
	(7,'公众号',0,1521466579);

/*!40000 ALTER TABLE `website_config_group` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
